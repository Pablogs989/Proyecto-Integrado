﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace TOP_Manage
{
    static class Utilidades
    {
        public static bool ValidaContra(MySqlConnection conexion, string passwd)
        {
            string consulta = string.Format("SELECT passwd FROM empleado;");
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            bool valida = false;
            try
            {
                MySqlDataReader reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (reader.GetString(0) == passwd)
                        {
                            valida = true;
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return valida;
        }
    }
}