﻿namespace TOP_Manage
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnParaLlevar = new System.Windows.Forms.Button();
            this.btnDomicilio = new System.Windows.Forms.Button();
            this.btnComedor = new System.Windows.Forms.Button();
            this.btnVerPedido = new System.Windows.Forms.Button();
            this.btnCerrarPedido = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnParaLlevar
            // 
            this.btnParaLlevar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(164)))), ((int)(((byte)(189)))));
            this.btnParaLlevar.FlatAppearance.BorderSize = 0;
            this.btnParaLlevar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnParaLlevar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnParaLlevar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParaLlevar.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnParaLlevar.ForeColor = System.Drawing.Color.White;
            this.btnParaLlevar.Location = new System.Drawing.Point(877, 41);
            this.btnParaLlevar.Name = "btnParaLlevar";
            this.btnParaLlevar.Size = new System.Drawing.Size(494, 138);
            this.btnParaLlevar.TabIndex = 1;
            this.btnParaLlevar.Text = "TAKE AWAY";
            this.btnParaLlevar.UseVisualStyleBackColor = false;
            this.btnParaLlevar.Click += new System.EventHandler(this.btnParaLlevar_Click);
            // 
            // btnDomicilio
            // 
            this.btnDomicilio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(114)))), ((int)(((byte)(139)))));
            this.btnDomicilio.FlatAppearance.BorderSize = 0;
            this.btnDomicilio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnDomicilio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnDomicilio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDomicilio.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnDomicilio.ForeColor = System.Drawing.Color.White;
            this.btnDomicilio.Location = new System.Drawing.Point(877, 240);
            this.btnDomicilio.Name = "btnDomicilio";
            this.btnDomicilio.Size = new System.Drawing.Size(494, 138);
            this.btnDomicilio.TabIndex = 2;
            this.btnDomicilio.Text = "DELIVERY";
            this.btnDomicilio.UseVisualStyleBackColor = false;
            this.btnDomicilio.Click += new System.EventHandler(this.btnDomicilio_Click);
            // 
            // btnComedor
            // 
            this.btnComedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(64)))), ((int)(((byte)(89)))));
            this.btnComedor.FlatAppearance.BorderSize = 0;
            this.btnComedor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnComedor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnComedor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComedor.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnComedor.ForeColor = System.Drawing.Color.White;
            this.btnComedor.Location = new System.Drawing.Point(877, 442);
            this.btnComedor.Name = "btnComedor";
            this.btnComedor.Size = new System.Drawing.Size(494, 138);
            this.btnComedor.TabIndex = 6;
            this.btnComedor.Text = "HERE";
            this.btnComedor.UseVisualStyleBackColor = false;
            this.btnComedor.Click += new System.EventHandler(this.btnComedor_Click);
            // 
            // btnVerPedido
            // 
            this.btnVerPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(14)))), ((int)(((byte)(39)))));
            this.btnVerPedido.FlatAppearance.BorderSize = 0;
            this.btnVerPedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnVerPedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnVerPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerPedido.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnVerPedido.ForeColor = System.Drawing.Color.White;
            this.btnVerPedido.Location = new System.Drawing.Point(877, 645);
            this.btnVerPedido.Name = "btnVerPedido";
            this.btnVerPedido.Size = new System.Drawing.Size(494, 138);
            this.btnVerPedido.TabIndex = 10;
            this.btnVerPedido.Text = "VIEW ORDER";
            this.btnVerPedido.UseVisualStyleBackColor = false;
            this.btnVerPedido.Click += new System.EventHandler(this.btnVerPedido_Click);
            // 
            // btnCerrarPedido
            // 
            this.btnCerrarPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnCerrarPedido.FlatAppearance.BorderSize = 0;
            this.btnCerrarPedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnCerrarPedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnCerrarPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarPedido.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnCerrarPedido.ForeColor = System.Drawing.Color.White;
            this.btnCerrarPedido.Location = new System.Drawing.Point(877, 847);
            this.btnCerrarPedido.Name = "btnCerrarPedido";
            this.btnCerrarPedido.Size = new System.Drawing.Size(494, 138);
            this.btnCerrarPedido.TabIndex = 13;
            this.btnCerrarPedido.Text = "CLOSE ORDER";
            this.btnCerrarPedido.UseVisualStyleBackColor = false;
            this.btnCerrarPedido.Click += new System.EventHandler(this.btnCerrarPedido_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.BackgroundImage = global::TOP_Manage.Properties.Resources.proximo;
            this.btnReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturn.FlatAppearance.BorderSize = 0;
            this.btnReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturn.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.btnReturn.ForeColor = System.Drawing.Color.Red;
            this.btnReturn.Location = new System.Drawing.Point(25, 811);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(87, 88);
            this.btnReturn.TabIndex = 22;
            this.btnReturn.UseCompatibleTextRendering = true;
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click_1);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.BackgroundImage = global::TOP_Manage.Properties.Resources.boton_de_encendido;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(25, 923);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(87, 88);
            this.btnClose.TabIndex = 19;
            this.btnClose.UseCompatibleTextRendering = true;
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCerrarPedido);
            this.Controls.Add(this.btnVerPedido);
            this.Controls.Add(this.btnComedor);
            this.Controls.Add(this.btnDomicilio);
            this.Controls.Add(this.btnParaLlevar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmPrincipal";
            this.Text = "Form2";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnParaLlevar;
        private System.Windows.Forms.Button btnDomicilio;
        private System.Windows.Forms.Button btnComedor;
        private System.Windows.Forms.Button btnVerPedido;
        private System.Windows.Forms.Button btnCerrarPedido;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnReturn;
    }
}