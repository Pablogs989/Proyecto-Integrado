﻿namespace TOP_Manage
{
    partial class FrmEntrante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnChickenWingsCombo = new System.Windows.Forms.RadioButton();
            this.radio6GarlicCheeseBread = new System.Windows.Forms.RadioButton();
            this.rbtnChickenCombo = new System.Windows.Forms.RadioButton();
            this.rbtnagua50cl = new System.Windows.Forms.RadioButton();
            this.rbtnagua1L = new System.Windows.Forms.RadioButton();
            this.rbtnagua2L = new System.Windows.Forms.RadioButton();
            this.rbtnChickenSalad = new System.Windows.Forms.RadioButton();
            this.rbtnCamembits = new System.Windows.Forms.RadioButton();
            this.rbtn6GarlicBread = new System.Windows.Forms.RadioButton();
            this.rbtnPotatoBacChees = new System.Windows.Forms.RadioButton();
            this.rbtnChickenWings = new System.Windows.Forms.RadioButton();
            this.rbtnCesarSalad = new System.Windows.Forms.RadioButton();
            this.rbtnChickenStrips = new System.Windows.Forms.RadioButton();
            this.rbtn4GarlicBread = new System.Windows.Forms.RadioButton();
            this.rbtnGroveSalad = new System.Windows.Forms.RadioButton();
            this.rbtnNuggets = new System.Windows.Forms.RadioButton();
            this.rbtn4GarlicCheeseBread = new System.Windows.Forms.RadioButton();
            this.rbtnPotatoes = new System.Windows.Forms.RadioButton();
            this.btnCerrarPedido = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnChickenWingsCombo);
            this.groupBox1.Controls.Add(this.radio6GarlicCheeseBread);
            this.groupBox1.Controls.Add(this.rbtnChickenCombo);
            this.groupBox1.Controls.Add(this.rbtnagua50cl);
            this.groupBox1.Controls.Add(this.rbtnagua1L);
            this.groupBox1.Controls.Add(this.rbtnagua2L);
            this.groupBox1.Controls.Add(this.rbtnChickenSalad);
            this.groupBox1.Controls.Add(this.rbtnCamembits);
            this.groupBox1.Controls.Add(this.rbtn6GarlicBread);
            this.groupBox1.Controls.Add(this.rbtnPotatoBacChees);
            this.groupBox1.Controls.Add(this.rbtnChickenWings);
            this.groupBox1.Controls.Add(this.rbtnCesarSalad);
            this.groupBox1.Controls.Add(this.rbtnChickenStrips);
            this.groupBox1.Controls.Add(this.rbtn4GarlicBread);
            this.groupBox1.Controls.Add(this.rbtnGroveSalad);
            this.groupBox1.Controls.Add(this.rbtnNuggets);
            this.groupBox1.Controls.Add(this.rbtn4GarlicCheeseBread);
            this.groupBox1.Controls.Add(this.rbtnPotatoes);
            this.groupBox1.Location = new System.Drawing.Point(126, 190);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1610, 571);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            // 
            // rbtnChickenWingsCombo
            // 
            this.rbtnChickenWingsCombo.AutoSize = true;
            this.rbtnChickenWingsCombo.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenWingsCombo.Location = new System.Drawing.Point(963, 416);
            this.rbtnChickenWingsCombo.Name = "rbtnChickenWingsCombo";
            this.rbtnChickenWingsCombo.Size = new System.Drawing.Size(349, 48);
            this.rbtnChickenWingsCombo.TabIndex = 42;
            this.rbtnChickenWingsCombo.TabStop = true;
            this.rbtnChickenWingsCombo.Text = "ChickenWingsCombo";
            this.rbtnChickenWingsCombo.UseVisualStyleBackColor = true;
            // 
            // radio6GarlicCheeseBread
            // 
            this.radio6GarlicCheeseBread.AutoSize = true;
            this.radio6GarlicCheeseBread.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.radio6GarlicCheeseBread.Location = new System.Drawing.Point(223, 416);
            this.radio6GarlicCheeseBread.Name = "radio6GarlicCheeseBread";
            this.radio6GarlicCheeseBread.Size = new System.Drawing.Size(341, 48);
            this.radio6GarlicCheeseBread.TabIndex = 41;
            this.radio6GarlicCheeseBread.TabStop = true;
            this.radio6GarlicCheeseBread.Text = "6GarlicCheeseBread";
            this.radio6GarlicCheeseBread.UseVisualStyleBackColor = true;
            // 
            // rbtnChickenCombo
            // 
            this.rbtnChickenCombo.AutoSize = true;
            this.rbtnChickenCombo.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenCombo.Location = new System.Drawing.Point(632, 416);
            this.rbtnChickenCombo.Name = "rbtnChickenCombo";
            this.rbtnChickenCombo.Size = new System.Drawing.Size(261, 48);
            this.rbtnChickenCombo.TabIndex = 40;
            this.rbtnChickenCombo.TabStop = true;
            this.rbtnChickenCombo.Text = "ChickenCombo";
            this.rbtnChickenCombo.UseVisualStyleBackColor = true;
            // 
            // rbtnagua50cl
            // 
            this.rbtnagua50cl.AutoSize = true;
            this.rbtnagua50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua50cl.Location = new System.Drawing.Point(1283, 104);
            this.rbtnagua50cl.Name = "rbtnagua50cl";
            this.rbtnagua50cl.Size = new System.Drawing.Size(172, 48);
            this.rbtnagua50cl.TabIndex = 39;
            this.rbtnagua50cl.TabStop = true;
            this.rbtnagua50cl.Text = "agua50cl";
            this.rbtnagua50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnagua1L
            // 
            this.rbtnagua1L.AutoSize = true;
            this.rbtnagua1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua1L.Location = new System.Drawing.Point(1283, 205);
            this.rbtnagua1L.Name = "rbtnagua1L";
            this.rbtnagua1L.Size = new System.Drawing.Size(149, 48);
            this.rbtnagua1L.TabIndex = 38;
            this.rbtnagua1L.TabStop = true;
            this.rbtnagua1L.Text = "agua1L";
            this.rbtnagua1L.UseVisualStyleBackColor = true;
            // 
            // rbtnagua2L
            // 
            this.rbtnagua2L.AutoSize = true;
            this.rbtnagua2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua2L.Location = new System.Drawing.Point(1283, 307);
            this.rbtnagua2L.Name = "rbtnagua2L";
            this.rbtnagua2L.Size = new System.Drawing.Size(149, 48);
            this.rbtnagua2L.TabIndex = 37;
            this.rbtnagua2L.TabStop = true;
            this.rbtnagua2L.Text = "agua2L";
            this.rbtnagua2L.UseVisualStyleBackColor = true;
            // 
            // rbtnChickenSalad
            // 
            this.rbtnChickenSalad.AutoSize = true;
            this.rbtnChickenSalad.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenSalad.Location = new System.Drawing.Point(963, 104);
            this.rbtnChickenSalad.Name = "rbtnChickenSalad";
            this.rbtnChickenSalad.Size = new System.Drawing.Size(239, 48);
            this.rbtnChickenSalad.TabIndex = 36;
            this.rbtnChickenSalad.TabStop = true;
            this.rbtnChickenSalad.Text = "ChickenSalad";
            this.rbtnChickenSalad.UseVisualStyleBackColor = true;
            // 
            // rbtnCamembits
            // 
            this.rbtnCamembits.AutoSize = true;
            this.rbtnCamembits.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCamembits.Location = new System.Drawing.Point(963, 205);
            this.rbtnCamembits.Name = "rbtnCamembits";
            this.rbtnCamembits.Size = new System.Drawing.Size(207, 48);
            this.rbtnCamembits.TabIndex = 35;
            this.rbtnCamembits.TabStop = true;
            this.rbtnCamembits.Text = "Camembits";
            this.rbtnCamembits.UseVisualStyleBackColor = true;
            // 
            // rbtn6GarlicBread
            // 
            this.rbtn6GarlicBread.AutoSize = true;
            this.rbtn6GarlicBread.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtn6GarlicBread.Location = new System.Drawing.Point(963, 307);
            this.rbtn6GarlicBread.Name = "rbtn6GarlicBread";
            this.rbtn6GarlicBread.Size = new System.Drawing.Size(231, 48);
            this.rbtn6GarlicBread.TabIndex = 34;
            this.rbtn6GarlicBread.TabStop = true;
            this.rbtn6GarlicBread.Text = "6GarlicBread";
            this.rbtn6GarlicBread.UseVisualStyleBackColor = true;
            // 
            // rbtnPotatoBacChees
            // 
            this.rbtnPotatoBacChees.AutoSize = true;
            this.rbtnPotatoBacChees.Font = new System.Drawing.Font("Yu Gothic Light", 19F);
            this.rbtnPotatoBacChees.Location = new System.Drawing.Point(75, 205);
            this.rbtnPotatoBacChees.Name = "rbtnPotatoBacChees";
            this.rbtnPotatoBacChees.Size = new System.Drawing.Size(267, 46);
            this.rbtnPotatoBacChees.TabIndex = 33;
            this.rbtnPotatoBacChees.TabStop = true;
            this.rbtnPotatoBacChees.Text = "PotatoBacChees";
            this.rbtnPotatoBacChees.UseVisualStyleBackColor = true;
            // 
            // rbtnChickenWings
            // 
            this.rbtnChickenWings.AutoSize = true;
            this.rbtnChickenWings.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenWings.Location = new System.Drawing.Point(75, 307);
            this.rbtnChickenWings.Name = "rbtnChickenWings";
            this.rbtnChickenWings.Size = new System.Drawing.Size(245, 48);
            this.rbtnChickenWings.TabIndex = 32;
            this.rbtnChickenWings.TabStop = true;
            this.rbtnChickenWings.Text = "ChickenWings";
            this.rbtnChickenWings.UseVisualStyleBackColor = true;
            // 
            // rbtnCesarSalad
            // 
            this.rbtnCesarSalad.AutoSize = true;
            this.rbtnCesarSalad.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCesarSalad.Location = new System.Drawing.Point(356, 104);
            this.rbtnCesarSalad.Name = "rbtnCesarSalad";
            this.rbtnCesarSalad.Size = new System.Drawing.Size(208, 48);
            this.rbtnCesarSalad.TabIndex = 31;
            this.rbtnCesarSalad.TabStop = true;
            this.rbtnCesarSalad.Text = "CesarSalad";
            this.rbtnCesarSalad.UseVisualStyleBackColor = true;
            // 
            // rbtnChickenStrips
            // 
            this.rbtnChickenStrips.AutoSize = true;
            this.rbtnChickenStrips.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenStrips.Location = new System.Drawing.Point(356, 205);
            this.rbtnChickenStrips.Name = "rbtnChickenStrips";
            this.rbtnChickenStrips.Size = new System.Drawing.Size(240, 48);
            this.rbtnChickenStrips.TabIndex = 30;
            this.rbtnChickenStrips.TabStop = true;
            this.rbtnChickenStrips.Text = "ChickenStrips";
            this.rbtnChickenStrips.UseVisualStyleBackColor = true;
            // 
            // rbtn4GarlicBread
            // 
            this.rbtn4GarlicBread.AutoSize = true;
            this.rbtn4GarlicBread.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtn4GarlicBread.Location = new System.Drawing.Point(356, 307);
            this.rbtn4GarlicBread.Name = "rbtn4GarlicBread";
            this.rbtn4GarlicBread.Size = new System.Drawing.Size(231, 48);
            this.rbtn4GarlicBread.TabIndex = 29;
            this.rbtn4GarlicBread.TabStop = true;
            this.rbtn4GarlicBread.Text = "4GarlicBread";
            this.rbtn4GarlicBread.UseVisualStyleBackColor = true;
            // 
            // rbtnGroveSalad
            // 
            this.rbtnGroveSalad.AutoSize = true;
            this.rbtnGroveSalad.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnGroveSalad.Location = new System.Drawing.Point(642, 104);
            this.rbtnGroveSalad.Name = "rbtnGroveSalad";
            this.rbtnGroveSalad.Size = new System.Drawing.Size(209, 48);
            this.rbtnGroveSalad.TabIndex = 28;
            this.rbtnGroveSalad.TabStop = true;
            this.rbtnGroveSalad.Text = "GroveSalad";
            this.rbtnGroveSalad.UseVisualStyleBackColor = true;
            // 
            // rbtnNuggets
            // 
            this.rbtnNuggets.AutoSize = true;
            this.rbtnNuggets.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnNuggets.Location = new System.Drawing.Point(642, 205);
            this.rbtnNuggets.Name = "rbtnNuggets";
            this.rbtnNuggets.Size = new System.Drawing.Size(161, 48);
            this.rbtnNuggets.TabIndex = 27;
            this.rbtnNuggets.TabStop = true;
            this.rbtnNuggets.Text = "Nuggets";
            this.rbtnNuggets.UseVisualStyleBackColor = true;
            // 
            // rbtn4GarlicCheeseBread
            // 
            this.rbtn4GarlicCheeseBread.AutoSize = true;
            this.rbtn4GarlicCheeseBread.Font = new System.Drawing.Font("Yu Gothic Light", 19F);
            this.rbtn4GarlicCheeseBread.Location = new System.Drawing.Point(642, 307);
            this.rbtn4GarlicCheeseBread.Name = "rbtn4GarlicCheeseBread";
            this.rbtn4GarlicCheeseBread.Size = new System.Drawing.Size(316, 46);
            this.rbtn4GarlicCheeseBread.TabIndex = 26;
            this.rbtn4GarlicCheeseBread.TabStop = true;
            this.rbtn4GarlicCheeseBread.Text = "4GarlicCheeseBread";
            this.rbtn4GarlicCheeseBread.UseVisualStyleBackColor = true;
            // 
            // rbtnPotatoes
            // 
            this.rbtnPotatoes.AutoSize = true;
            this.rbtnPotatoes.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnPotatoes.Location = new System.Drawing.Point(75, 104);
            this.rbtnPotatoes.Name = "rbtnPotatoes";
            this.rbtnPotatoes.Size = new System.Drawing.Size(169, 48);
            this.rbtnPotatoes.TabIndex = 25;
            this.rbtnPotatoes.TabStop = true;
            this.rbtnPotatoes.Text = "Potatoes";
            this.rbtnPotatoes.UseVisualStyleBackColor = true;
            // 
            // btnCerrarPedido
            // 
            this.btnCerrarPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnCerrarPedido.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrarPedido.FlatAppearance.BorderSize = 0;
            this.btnCerrarPedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnCerrarPedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnCerrarPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarPedido.Font = new System.Drawing.Font("Yu Gothic Light", 17F);
            this.btnCerrarPedido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(194)))), ((int)(((byte)(209)))));
            this.btnCerrarPedido.Location = new System.Drawing.Point(1507, 933);
            this.btnCerrarPedido.Name = "btnCerrarPedido";
            this.btnCerrarPedido.Size = new System.Drawing.Size(335, 60);
            this.btnCerrarPedido.TabIndex = 31;
            this.btnCerrarPedido.Text = "ADD";
            this.btnCerrarPedido.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.BackgroundImage = global::TOP_Manage.Properties.Resources.correcto__2_;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(44, 905);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 88);
            this.button4.TabIndex = 30;
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // FrmEntrante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCerrarPedido);
            this.Controls.Add(this.button4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmEntrante";
            this.Text = "Form12";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnagua50cl;
        private System.Windows.Forms.RadioButton rbtnagua1L;
        private System.Windows.Forms.RadioButton rbtnagua2L;
        private System.Windows.Forms.RadioButton rbtnChickenSalad;
        private System.Windows.Forms.RadioButton rbtnCamembits;
        private System.Windows.Forms.RadioButton rbtn6GarlicBread;
        private System.Windows.Forms.RadioButton rbtnPotatoBacChees;
        private System.Windows.Forms.RadioButton rbtnChickenWings;
        private System.Windows.Forms.RadioButton rbtnCesarSalad;
        private System.Windows.Forms.RadioButton rbtnChickenStrips;
        private System.Windows.Forms.RadioButton rbtn4GarlicBread;
        private System.Windows.Forms.RadioButton rbtnGroveSalad;
        private System.Windows.Forms.RadioButton rbtnNuggets;
        private System.Windows.Forms.RadioButton rbtn4GarlicCheeseBread;
        private System.Windows.Forms.RadioButton rbtnPotatoes;
        private System.Windows.Forms.Button btnCerrarPedido;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RadioButton rbtnChickenWingsCombo;
        private System.Windows.Forms.RadioButton radio6GarlicCheeseBread;
        private System.Windows.Forms.RadioButton rbtnChickenCombo;
    }
}