﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOP_Manage
{
    public partial class FrmCocina : Form
    {
        public FrmCocina()
        {
            InitializeComponent();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmContraseña frmContra = new FrmContraseña();
            frmContra.Show();
            this.Dispose();
        }

        private void LlenarDtg(DataGridView dtg, List<LineaPedido> lineas)
        {
            foreach (LineaPedido linea in lineas)
            {
                dtg.Rows.Add(linea.NPed, linea.Producto.Tipo.Descripcion, linea.Producto.Detalle, linea.Cant);
            }
        }

        private void FrmCocina_Load(object sender, EventArgs e)
        {
            ConexionBD conex = new ConexionBD();
            conex.AbrirConexion();
            LlenarDtg(dtgLineas, LineaPedido.GetLineasNoHechas(conex.Conexion));
            conex.CerrarConexion();
        }
    }
}
