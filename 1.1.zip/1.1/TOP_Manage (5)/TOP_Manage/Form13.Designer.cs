﻿namespace TOP_Manage
{
    partial class FrmPizza
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnPatanegra = new System.Windows.Forms.RadioButton();
            this.rbtnCheesix = new System.Windows.Forms.RadioButton();
            this.rbtnCarnal = new System.Windows.Forms.RadioButton();
            this.rbtnagua50cl = new System.Windows.Forms.RadioButton();
            this.rbtnagua1L = new System.Windows.Forms.RadioButton();
            this.rbtnagua2L = new System.Windows.Forms.RadioButton();
            this.rbtnCampina = new System.Windows.Forms.RadioButton();
            this.rbtnBarbecue = new System.Windows.Forms.RadioButton();
            this.rbtn4Cheeses = new System.Windows.Forms.RadioButton();
            this.rbtnPeperoni = new System.Windows.Forms.RadioButton();
            this.rbtnHawaiian = new System.Windows.Forms.RadioButton();
            this.rbtnGrillChick = new System.Windows.Forms.RadioButton();
            this.rbtnExtravag = new System.Windows.Forms.RadioButton();
            this.rbtnCremBour = new System.Windows.Forms.RadioButton();
            this.rbtnGroveSalad = new System.Windows.Forms.RadioButton();
            this.rbtnCremBBQ = new System.Windows.Forms.RadioButton();
            this.rbtnCarbonara = new System.Windows.Forms.RadioButton();
            this.rbtnMarguerite = new System.Windows.Forms.RadioButton();
            this.btnCerrarPedido = new System.Windows.Forms.Button();
            this.rbtnGoatmel = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnGoatmel);
            this.groupBox1.Controls.Add(this.rbtnPatanegra);
            this.groupBox1.Controls.Add(this.rbtnCheesix);
            this.groupBox1.Controls.Add(this.rbtnCarnal);
            this.groupBox1.Controls.Add(this.rbtnagua50cl);
            this.groupBox1.Controls.Add(this.rbtnagua1L);
            this.groupBox1.Controls.Add(this.rbtnagua2L);
            this.groupBox1.Controls.Add(this.rbtnCampina);
            this.groupBox1.Controls.Add(this.rbtnBarbecue);
            this.groupBox1.Controls.Add(this.rbtn4Cheeses);
            this.groupBox1.Controls.Add(this.rbtnPeperoni);
            this.groupBox1.Controls.Add(this.rbtnHawaiian);
            this.groupBox1.Controls.Add(this.rbtnGrillChick);
            this.groupBox1.Controls.Add(this.rbtnExtravag);
            this.groupBox1.Controls.Add(this.rbtnCremBour);
            this.groupBox1.Controls.Add(this.rbtnGroveSalad);
            this.groupBox1.Controls.Add(this.rbtnCremBBQ);
            this.groupBox1.Controls.Add(this.rbtnCarbonara);
            this.groupBox1.Controls.Add(this.rbtnMarguerite);
            this.groupBox1.Location = new System.Drawing.Point(141, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1610, 501);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            // 
            // rbtnPatanegra
            // 
            this.rbtnPatanegra.AutoSize = true;
            this.rbtnPatanegra.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnPatanegra.Location = new System.Drawing.Point(963, 396);
            this.rbtnPatanegra.Name = "rbtnPatanegra";
            this.rbtnPatanegra.Size = new System.Drawing.Size(189, 48);
            this.rbtnPatanegra.TabIndex = 42;
            this.rbtnPatanegra.TabStop = true;
            this.rbtnPatanegra.Text = "Patanegra";
            this.rbtnPatanegra.UseVisualStyleBackColor = true;
            // 
            // rbtnCheesix
            // 
            this.rbtnCheesix.AutoSize = true;
            this.rbtnCheesix.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCheesix.Location = new System.Drawing.Point(75, 396);
            this.rbtnCheesix.Name = "rbtnCheesix";
            this.rbtnCheesix.Size = new System.Drawing.Size(156, 48);
            this.rbtnCheesix.TabIndex = 41;
            this.rbtnCheesix.TabStop = true;
            this.rbtnCheesix.Text = "Cheesix";
            this.rbtnCheesix.UseVisualStyleBackColor = true;
            // 
            // rbtnCarnal
            // 
            this.rbtnCarnal.AutoSize = true;
            this.rbtnCarnal.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCarnal.Location = new System.Drawing.Point(642, 396);
            this.rbtnCarnal.Name = "rbtnCarnal";
            this.rbtnCarnal.Size = new System.Drawing.Size(136, 48);
            this.rbtnCarnal.TabIndex = 40;
            this.rbtnCarnal.TabStop = true;
            this.rbtnCarnal.Text = "Carnal";
            this.rbtnCarnal.UseVisualStyleBackColor = true;
            // 
            // rbtnagua50cl
            // 
            this.rbtnagua50cl.AutoSize = true;
            this.rbtnagua50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua50cl.Location = new System.Drawing.Point(1283, 104);
            this.rbtnagua50cl.Name = "rbtnagua50cl";
            this.rbtnagua50cl.Size = new System.Drawing.Size(172, 48);
            this.rbtnagua50cl.TabIndex = 39;
            this.rbtnagua50cl.TabStop = true;
            this.rbtnagua50cl.Text = "agua50cl";
            this.rbtnagua50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnagua1L
            // 
            this.rbtnagua1L.AutoSize = true;
            this.rbtnagua1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua1L.Location = new System.Drawing.Point(1283, 205);
            this.rbtnagua1L.Name = "rbtnagua1L";
            this.rbtnagua1L.Size = new System.Drawing.Size(149, 48);
            this.rbtnagua1L.TabIndex = 38;
            this.rbtnagua1L.TabStop = true;
            this.rbtnagua1L.Text = "agua1L";
            this.rbtnagua1L.UseVisualStyleBackColor = true;
            // 
            // rbtnagua2L
            // 
            this.rbtnagua2L.AutoSize = true;
            this.rbtnagua2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua2L.Location = new System.Drawing.Point(1283, 307);
            this.rbtnagua2L.Name = "rbtnagua2L";
            this.rbtnagua2L.Size = new System.Drawing.Size(149, 48);
            this.rbtnagua2L.TabIndex = 37;
            this.rbtnagua2L.TabStop = true;
            this.rbtnagua2L.Text = "agua2L";
            this.rbtnagua2L.UseVisualStyleBackColor = true;
            // 
            // rbtnCampina
            // 
            this.rbtnCampina.AutoSize = true;
            this.rbtnCampina.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCampina.Location = new System.Drawing.Point(963, 104);
            this.rbtnCampina.Name = "rbtnCampina";
            this.rbtnCampina.Size = new System.Drawing.Size(171, 48);
            this.rbtnCampina.TabIndex = 36;
            this.rbtnCampina.TabStop = true;
            this.rbtnCampina.Text = "Campina";
            this.rbtnCampina.UseVisualStyleBackColor = true;
            // 
            // rbtnBarbecue
            // 
            this.rbtnBarbecue.AutoSize = true;
            this.rbtnBarbecue.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnBarbecue.Location = new System.Drawing.Point(963, 205);
            this.rbtnBarbecue.Name = "rbtnBarbecue";
            this.rbtnBarbecue.Size = new System.Drawing.Size(180, 48);
            this.rbtnBarbecue.TabIndex = 35;
            this.rbtnBarbecue.TabStop = true;
            this.rbtnBarbecue.Text = "Barbecue";
            this.rbtnBarbecue.UseVisualStyleBackColor = true;
            // 
            // rbtn4Cheeses
            // 
            this.rbtn4Cheeses.AutoSize = true;
            this.rbtn4Cheeses.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtn4Cheeses.Location = new System.Drawing.Point(963, 307);
            this.rbtn4Cheeses.Name = "rbtn4Cheeses";
            this.rbtn4Cheeses.Size = new System.Drawing.Size(185, 48);
            this.rbtn4Cheeses.TabIndex = 34;
            this.rbtn4Cheeses.TabStop = true;
            this.rbtn4Cheeses.Text = "4Cheeses";
            this.rbtn4Cheeses.UseVisualStyleBackColor = true;
            // 
            // rbtnPeperoni
            // 
            this.rbtnPeperoni.AutoSize = true;
            this.rbtnPeperoni.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnPeperoni.Location = new System.Drawing.Point(75, 205);
            this.rbtnPeperoni.Name = "rbtnPeperoni";
            this.rbtnPeperoni.Size = new System.Drawing.Size(170, 48);
            this.rbtnPeperoni.TabIndex = 33;
            this.rbtnPeperoni.TabStop = true;
            this.rbtnPeperoni.Text = "Peperoni";
            this.rbtnPeperoni.UseVisualStyleBackColor = true;
            // 
            // rbtnHawaiian
            // 
            this.rbtnHawaiian.AutoSize = true;
            this.rbtnHawaiian.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHawaiian.Location = new System.Drawing.Point(75, 307);
            this.rbtnHawaiian.Name = "rbtnHawaiian";
            this.rbtnHawaiian.Size = new System.Drawing.Size(187, 48);
            this.rbtnHawaiian.TabIndex = 32;
            this.rbtnHawaiian.TabStop = true;
            this.rbtnHawaiian.Text = " Hawaiian";
            this.rbtnHawaiian.UseVisualStyleBackColor = true;
            // 
            // rbtnGrillChick
            // 
            this.rbtnGrillChick.AutoSize = true;
            this.rbtnGrillChick.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnGrillChick.Location = new System.Drawing.Point(356, 104);
            this.rbtnGrillChick.Name = "rbtnGrillChick";
            this.rbtnGrillChick.Size = new System.Drawing.Size(180, 48);
            this.rbtnGrillChick.TabIndex = 31;
            this.rbtnGrillChick.TabStop = true;
            this.rbtnGrillChick.Text = "GrillChick";
            this.rbtnGrillChick.UseVisualStyleBackColor = true;
            // 
            // rbtnExtravag
            // 
            this.rbtnExtravag.AutoSize = true;
            this.rbtnExtravag.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnExtravag.Location = new System.Drawing.Point(356, 205);
            this.rbtnExtravag.Name = "rbtnExtravag";
            this.rbtnExtravag.Size = new System.Drawing.Size(165, 48);
            this.rbtnExtravag.TabIndex = 30;
            this.rbtnExtravag.TabStop = true;
            this.rbtnExtravag.Text = "Extravag";
            this.rbtnExtravag.UseVisualStyleBackColor = true;
            // 
            // rbtnCremBour
            // 
            this.rbtnCremBour.AutoSize = true;
            this.rbtnCremBour.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCremBour.Location = new System.Drawing.Point(356, 307);
            this.rbtnCremBour.Name = "rbtnCremBour";
            this.rbtnCremBour.Size = new System.Drawing.Size(189, 48);
            this.rbtnCremBour.TabIndex = 29;
            this.rbtnCremBour.TabStop = true;
            this.rbtnCremBour.Text = "CremBour";
            this.rbtnCremBour.UseVisualStyleBackColor = true;
            // 
            // rbtnGroveSalad
            // 
            this.rbtnGroveSalad.AutoSize = true;
            this.rbtnGroveSalad.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnGroveSalad.Location = new System.Drawing.Point(642, 104);
            this.rbtnGroveSalad.Name = "rbtnGroveSalad";
            this.rbtnGroveSalad.Size = new System.Drawing.Size(209, 48);
            this.rbtnGroveSalad.TabIndex = 28;
            this.rbtnGroveSalad.TabStop = true;
            this.rbtnGroveSalad.Text = "GroveSalad";
            this.rbtnGroveSalad.UseVisualStyleBackColor = true;
            // 
            // rbtnCremBBQ
            // 
            this.rbtnCremBBQ.AutoSize = true;
            this.rbtnCremBBQ.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCremBBQ.Location = new System.Drawing.Point(642, 205);
            this.rbtnCremBBQ.Name = "rbtnCremBBQ";
            this.rbtnCremBBQ.Size = new System.Drawing.Size(188, 48);
            this.rbtnCremBBQ.TabIndex = 27;
            this.rbtnCremBBQ.TabStop = true;
            this.rbtnCremBBQ.Text = "CremBBQ";
            this.rbtnCremBBQ.UseVisualStyleBackColor = true;
            // 
            // rbtnCarbonara
            // 
            this.rbtnCarbonara.AutoSize = true;
            this.rbtnCarbonara.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCarbonara.Location = new System.Drawing.Point(642, 307);
            this.rbtnCarbonara.Name = "rbtnCarbonara";
            this.rbtnCarbonara.Size = new System.Drawing.Size(193, 48);
            this.rbtnCarbonara.TabIndex = 26;
            this.rbtnCarbonara.TabStop = true;
            this.rbtnCarbonara.Text = "Carbonara";
            this.rbtnCarbonara.UseVisualStyleBackColor = true;
            // 
            // rbtnMarguerite
            // 
            this.rbtnMarguerite.AutoSize = true;
            this.rbtnMarguerite.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnMarguerite.Location = new System.Drawing.Point(75, 104);
            this.rbtnMarguerite.Name = "rbtnMarguerite";
            this.rbtnMarguerite.Size = new System.Drawing.Size(210, 48);
            this.rbtnMarguerite.TabIndex = 25;
            this.rbtnMarguerite.TabStop = true;
            this.rbtnMarguerite.Text = "Marguerite ";
            this.rbtnMarguerite.UseVisualStyleBackColor = true;
            // 
            // btnCerrarPedido
            // 
            this.btnCerrarPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnCerrarPedido.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrarPedido.FlatAppearance.BorderSize = 0;
            this.btnCerrarPedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnCerrarPedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnCerrarPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarPedido.Font = new System.Drawing.Font("Yu Gothic Light", 17F);
            this.btnCerrarPedido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(194)))), ((int)(((byte)(209)))));
            this.btnCerrarPedido.Location = new System.Drawing.Point(1516, 921);
            this.btnCerrarPedido.Name = "btnCerrarPedido";
            this.btnCerrarPedido.Size = new System.Drawing.Size(335, 60);
            this.btnCerrarPedido.TabIndex = 34;
            this.btnCerrarPedido.Text = "ADD";
            this.btnCerrarPedido.UseVisualStyleBackColor = false;
            // 
            // rbtnGoatmel
            // 
            this.rbtnGoatmel.AutoSize = true;
            this.rbtnGoatmel.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnGoatmel.Location = new System.Drawing.Point(356, 396);
            this.rbtnGoatmel.Name = "rbtnGoatmel";
            this.rbtnGoatmel.Size = new System.Drawing.Size(165, 48);
            this.rbtnGoatmel.TabIndex = 43;
            this.rbtnGoatmel.TabStop = true;
            this.rbtnGoatmel.Text = "Goatmel";
            this.rbtnGoatmel.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Medium",
            "Large"});
            this.comboBox1.Location = new System.Drawing.Point(457, 730);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(307, 51);
            this.comboBox1.TabIndex = 36;
            this.comboBox1.Text = "SIZE";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Thin",
            "Original"});
            this.comboBox2.Location = new System.Drawing.Point(874, 730);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(307, 51);
            this.comboBox2.TabIndex = 37;
            this.comboBox2.Text = "MASS";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.BackgroundImage = global::TOP_Manage.Properties.Resources.correcto__2_;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(40, 904);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 88);
            this.button4.TabIndex = 33;
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // FrmPizza
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCerrarPedido);
            this.Controls.Add(this.button4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FrmPizza";
            this.Text = "Form13";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnPatanegra;
        private System.Windows.Forms.RadioButton rbtnCheesix;
        private System.Windows.Forms.RadioButton rbtnCarnal;
        private System.Windows.Forms.RadioButton rbtnagua50cl;
        private System.Windows.Forms.RadioButton rbtnagua1L;
        private System.Windows.Forms.RadioButton rbtnagua2L;
        private System.Windows.Forms.RadioButton rbtnCampina;
        private System.Windows.Forms.RadioButton rbtnBarbecue;
        private System.Windows.Forms.RadioButton rbtn4Cheeses;
        private System.Windows.Forms.RadioButton rbtnPeperoni;
        private System.Windows.Forms.RadioButton rbtnHawaiian;
        private System.Windows.Forms.RadioButton rbtnGrillChick;
        private System.Windows.Forms.RadioButton rbtnExtravag;
        private System.Windows.Forms.RadioButton rbtnCremBour;
        private System.Windows.Forms.RadioButton rbtnGroveSalad;
        private System.Windows.Forms.RadioButton rbtnCremBBQ;
        private System.Windows.Forms.RadioButton rbtnCarbonara;
        private System.Windows.Forms.RadioButton rbtnMarguerite;
        private System.Windows.Forms.Button btnCerrarPedido;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RadioButton rbtnGoatmel;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
    }
}