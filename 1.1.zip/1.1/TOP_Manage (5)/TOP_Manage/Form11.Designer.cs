﻿namespace TOP_Manage
{
    partial class FrmBebida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnLataFNaranja = new System.Windows.Forms.RadioButton();
            this.rbtnLataFLimon = new System.Windows.Forms.RadioButton();
            this.rbtnCocacola50cl = new System.Windows.Forms.RadioButton();
            this.rbtnCocaCola1L = new System.Windows.Forms.RadioButton();
            this.rbtnCocaCola2L = new System.Windows.Forms.RadioButton();
            this.rbtnFNaranja50cl = new System.Windows.Forms.RadioButton();
            this.rbtnFNaranja1L = new System.Windows.Forms.RadioButton();
            this.rbtnFNaranja2L = new System.Windows.Forms.RadioButton();
            this.rbtnLataCocaCola = new System.Windows.Forms.RadioButton();
            this.btnCerrarPedido = new System.Windows.Forms.Button();
            this.rbtnFLimon50cl = new System.Windows.Forms.RadioButton();
            this.rbtnFLimon1L = new System.Windows.Forms.RadioButton();
            this.rbtnFLimon2L = new System.Windows.Forms.RadioButton();
            this.rbtnagua50cl = new System.Windows.Forms.RadioButton();
            this.rbtnagua1L = new System.Windows.Forms.RadioButton();
            this.rbtnagua2L = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnagua50cl);
            this.groupBox1.Controls.Add(this.rbtnagua1L);
            this.groupBox1.Controls.Add(this.rbtnagua2L);
            this.groupBox1.Controls.Add(this.rbtnFLimon50cl);
            this.groupBox1.Controls.Add(this.rbtnFLimon1L);
            this.groupBox1.Controls.Add(this.rbtnFLimon2L);
            this.groupBox1.Controls.Add(this.rbtnLataFNaranja);
            this.groupBox1.Controls.Add(this.rbtnLataFLimon);
            this.groupBox1.Controls.Add(this.rbtnCocacola50cl);
            this.groupBox1.Controls.Add(this.rbtnCocaCola1L);
            this.groupBox1.Controls.Add(this.rbtnCocaCola2L);
            this.groupBox1.Controls.Add(this.rbtnFNaranja50cl);
            this.groupBox1.Controls.Add(this.rbtnFNaranja1L);
            this.groupBox1.Controls.Add(this.rbtnFNaranja2L);
            this.groupBox1.Controls.Add(this.rbtnLataCocaCola);
            this.groupBox1.Location = new System.Drawing.Point(119, 273);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1610, 489);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            // 
            // rbtnLataFNaranja
            // 
            this.rbtnLataFNaranja.AutoSize = true;
            this.rbtnLataFNaranja.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnLataFNaranja.Location = new System.Drawing.Point(75, 205);
            this.rbtnLataFNaranja.Name = "rbtnLataFNaranja";
            this.rbtnLataFNaranja.Size = new System.Drawing.Size(242, 48);
            this.rbtnLataFNaranja.TabIndex = 33;
            this.rbtnLataFNaranja.TabStop = true;
            this.rbtnLataFNaranja.Text = "LataFNaranja";
            this.rbtnLataFNaranja.UseVisualStyleBackColor = true;
            // 
            // rbtnLataFLimon
            // 
            this.rbtnLataFLimon.AutoSize = true;
            this.rbtnLataFLimon.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnLataFLimon.Location = new System.Drawing.Point(75, 307);
            this.rbtnLataFLimon.Name = "rbtnLataFLimon";
            this.rbtnLataFLimon.Size = new System.Drawing.Size(217, 48);
            this.rbtnLataFLimon.TabIndex = 32;
            this.rbtnLataFLimon.TabStop = true;
            this.rbtnLataFLimon.Text = "LataFLimon";
            this.rbtnLataFLimon.UseVisualStyleBackColor = true;
            // 
            // rbtnCocacola50cl
            // 
            this.rbtnCocacola50cl.AutoSize = true;
            this.rbtnCocacola50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCocacola50cl.Location = new System.Drawing.Point(356, 104);
            this.rbtnCocacola50cl.Name = "rbtnCocacola50cl";
            this.rbtnCocacola50cl.Size = new System.Drawing.Size(235, 48);
            this.rbtnCocacola50cl.TabIndex = 31;
            this.rbtnCocacola50cl.TabStop = true;
            this.rbtnCocacola50cl.Text = "Cocacola50cl";
            this.rbtnCocacola50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnCocaCola1L
            // 
            this.rbtnCocaCola1L.AutoSize = true;
            this.rbtnCocaCola1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCocaCola1L.Location = new System.Drawing.Point(356, 205);
            this.rbtnCocaCola1L.Name = "rbtnCocaCola1L";
            this.rbtnCocaCola1L.Size = new System.Drawing.Size(218, 48);
            this.rbtnCocaCola1L.TabIndex = 30;
            this.rbtnCocaCola1L.TabStop = true;
            this.rbtnCocaCola1L.Text = "CocaCola1L";
            this.rbtnCocaCola1L.UseVisualStyleBackColor = true;
            // 
            // rbtnCocaCola2L
            // 
            this.rbtnCocaCola2L.AutoSize = true;
            this.rbtnCocaCola2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCocaCola2L.Location = new System.Drawing.Point(356, 307);
            this.rbtnCocaCola2L.Name = "rbtnCocaCola2L";
            this.rbtnCocaCola2L.Size = new System.Drawing.Size(218, 48);
            this.rbtnCocaCola2L.TabIndex = 29;
            this.rbtnCocaCola2L.TabStop = true;
            this.rbtnCocaCola2L.Text = "CocaCola2L";
            this.rbtnCocaCola2L.UseVisualStyleBackColor = true;
            // 
            // rbtnFNaranja50cl
            // 
            this.rbtnFNaranja50cl.AutoSize = true;
            this.rbtnFNaranja50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFNaranja50cl.Location = new System.Drawing.Point(642, 104);
            this.rbtnFNaranja50cl.Name = "rbtnFNaranja50cl";
            this.rbtnFNaranja50cl.Size = new System.Drawing.Size(237, 48);
            this.rbtnFNaranja50cl.TabIndex = 28;
            this.rbtnFNaranja50cl.TabStop = true;
            this.rbtnFNaranja50cl.Text = "FNaranja50cl";
            this.rbtnFNaranja50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnFNaranja1L
            // 
            this.rbtnFNaranja1L.AutoSize = true;
            this.rbtnFNaranja1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFNaranja1L.Location = new System.Drawing.Point(642, 205);
            this.rbtnFNaranja1L.Name = "rbtnFNaranja1L";
            this.rbtnFNaranja1L.Size = new System.Drawing.Size(214, 48);
            this.rbtnFNaranja1L.TabIndex = 27;
            this.rbtnFNaranja1L.TabStop = true;
            this.rbtnFNaranja1L.Text = "FNaranja1L";
            this.rbtnFNaranja1L.UseVisualStyleBackColor = true;
            // 
            // rbtnFNaranja2L
            // 
            this.rbtnFNaranja2L.AutoSize = true;
            this.rbtnFNaranja2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFNaranja2L.Location = new System.Drawing.Point(642, 307);
            this.rbtnFNaranja2L.Name = "rbtnFNaranja2L";
            this.rbtnFNaranja2L.Size = new System.Drawing.Size(214, 48);
            this.rbtnFNaranja2L.TabIndex = 26;
            this.rbtnFNaranja2L.TabStop = true;
            this.rbtnFNaranja2L.Text = "FNaranja2L";
            this.rbtnFNaranja2L.UseVisualStyleBackColor = true;
            // 
            // rbtnLataCocaCola
            // 
            this.rbtnLataCocaCola.AutoSize = true;
            this.rbtnLataCocaCola.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnLataCocaCola.Location = new System.Drawing.Point(75, 104);
            this.rbtnLataCocaCola.Name = "rbtnLataCocaCola";
            this.rbtnLataCocaCola.Size = new System.Drawing.Size(246, 48);
            this.rbtnLataCocaCola.TabIndex = 25;
            this.rbtnLataCocaCola.TabStop = true;
            this.rbtnLataCocaCola.Text = "LataCocaCola";
            this.rbtnLataCocaCola.UseVisualStyleBackColor = true;
            // 
            // btnCerrarPedido
            // 
            this.btnCerrarPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnCerrarPedido.FlatAppearance.BorderSize = 0;
            this.btnCerrarPedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnCerrarPedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnCerrarPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarPedido.Font = new System.Drawing.Font("Yu Gothic Light", 17F);
            this.btnCerrarPedido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(194)))), ((int)(((byte)(209)))));
            this.btnCerrarPedido.Location = new System.Drawing.Point(1504, 932);
            this.btnCerrarPedido.Name = "btnCerrarPedido";
            this.btnCerrarPedido.Size = new System.Drawing.Size(335, 60);
            this.btnCerrarPedido.TabIndex = 28;
            this.btnCerrarPedido.Text = "ADD";
            this.btnCerrarPedido.UseVisualStyleBackColor = false;
            // 
            // rbtnFLimon50cl
            // 
            this.rbtnFLimon50cl.AutoSize = true;
            this.rbtnFLimon50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFLimon50cl.Location = new System.Drawing.Point(963, 104);
            this.rbtnFLimon50cl.Name = "rbtnFLimon50cl";
            this.rbtnFLimon50cl.Size = new System.Drawing.Size(212, 48);
            this.rbtnFLimon50cl.TabIndex = 36;
            this.rbtnFLimon50cl.TabStop = true;
            this.rbtnFLimon50cl.Text = "FLimon50cl";
            this.rbtnFLimon50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnFLimon1L
            // 
            this.rbtnFLimon1L.AutoSize = true;
            this.rbtnFLimon1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFLimon1L.Location = new System.Drawing.Point(963, 205);
            this.rbtnFLimon1L.Name = "rbtnFLimon1L";
            this.rbtnFLimon1L.Size = new System.Drawing.Size(189, 48);
            this.rbtnFLimon1L.TabIndex = 35;
            this.rbtnFLimon1L.TabStop = true;
            this.rbtnFLimon1L.Text = "FLimon1L";
            this.rbtnFLimon1L.UseVisualStyleBackColor = true;
            // 
            // rbtnFLimon2L
            // 
            this.rbtnFLimon2L.AutoSize = true;
            this.rbtnFLimon2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFLimon2L.Location = new System.Drawing.Point(963, 307);
            this.rbtnFLimon2L.Name = "rbtnFLimon2L";
            this.rbtnFLimon2L.Size = new System.Drawing.Size(189, 48);
            this.rbtnFLimon2L.TabIndex = 34;
            this.rbtnFLimon2L.TabStop = true;
            this.rbtnFLimon2L.Text = "FLimon2L";
            this.rbtnFLimon2L.UseVisualStyleBackColor = true;
            // 
            // rbtnagua50cl
            // 
            this.rbtnagua50cl.AutoSize = true;
            this.rbtnagua50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua50cl.Location = new System.Drawing.Point(1283, 104);
            this.rbtnagua50cl.Name = "rbtnagua50cl";
            this.rbtnagua50cl.Size = new System.Drawing.Size(172, 48);
            this.rbtnagua50cl.TabIndex = 39;
            this.rbtnagua50cl.TabStop = true;
            this.rbtnagua50cl.Text = "agua50cl";
            this.rbtnagua50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnagua1L
            // 
            this.rbtnagua1L.AutoSize = true;
            this.rbtnagua1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua1L.Location = new System.Drawing.Point(1283, 205);
            this.rbtnagua1L.Name = "rbtnagua1L";
            this.rbtnagua1L.Size = new System.Drawing.Size(149, 48);
            this.rbtnagua1L.TabIndex = 38;
            this.rbtnagua1L.TabStop = true;
            this.rbtnagua1L.Text = "agua1L";
            this.rbtnagua1L.UseVisualStyleBackColor = true;
            // 
            // rbtnagua2L
            // 
            this.rbtnagua2L.AutoSize = true;
            this.rbtnagua2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua2L.Location = new System.Drawing.Point(1283, 307);
            this.rbtnagua2L.Name = "rbtnagua2L";
            this.rbtnagua2L.Size = new System.Drawing.Size(149, 48);
            this.rbtnagua2L.TabIndex = 37;
            this.rbtnagua2L.TabStop = true;
            this.rbtnagua2L.Text = "agua2L";
            this.rbtnagua2L.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.BackgroundImage = global::TOP_Manage.Properties.Resources.correcto__2_;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(41, 904);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 88);
            this.button4.TabIndex = 27;
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // FrmBebida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCerrarPedido);
            this.Controls.Add(this.button4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FrmBebida";
            this.Text = "Form11";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnLataFNaranja;
        private System.Windows.Forms.RadioButton rbtnLataFLimon;
        private System.Windows.Forms.RadioButton rbtnCocacola50cl;
        private System.Windows.Forms.RadioButton rbtnCocaCola1L;
        private System.Windows.Forms.RadioButton rbtnCocaCola2L;
        private System.Windows.Forms.RadioButton rbtnFNaranja50cl;
        private System.Windows.Forms.RadioButton rbtnFNaranja1L;
        private System.Windows.Forms.RadioButton rbtnFNaranja2L;
        private System.Windows.Forms.RadioButton rbtnLataCocaCola;
        private System.Windows.Forms.Button btnCerrarPedido;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RadioButton rbtnagua50cl;
        private System.Windows.Forms.RadioButton rbtnagua1L;
        private System.Windows.Forms.RadioButton rbtnagua2L;
        private System.Windows.Forms.RadioButton rbtnFLimon50cl;
        private System.Windows.Forms.RadioButton rbtnFLimon1L;
        private System.Windows.Forms.RadioButton rbtnFLimon2L;
    }
}