﻿namespace TOP_Manage
{
    partial class FrmPostre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCerrarPedido = new System.Windows.Forms.Button();
            this.rbtnBrownie = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnTartaChocolate = new System.Windows.Forms.RadioButton();
            this.rbtnHeladoTartaFresa = new System.Windows.Forms.RadioButton();
            this.rbtnHeladoCookies = new System.Windows.Forms.RadioButton();
            this.rbtnHeladoBrownie = new System.Windows.Forms.RadioButton();
            this.rbtnHeladoPeanut = new System.Windows.Forms.RadioButton();
            this.rbtnVulcano = new System.Windows.Forms.RadioButton();
            this.rbtnChococheese = new System.Windows.Forms.RadioButton();
            this.rbtnCookies = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCerrarPedido
            // 
            this.btnCerrarPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnCerrarPedido.FlatAppearance.BorderSize = 0;
            this.btnCerrarPedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnCerrarPedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnCerrarPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarPedido.Font = new System.Drawing.Font("Yu Gothic Light", 17F);
            this.btnCerrarPedido.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(194)))), ((int)(((byte)(209)))));
            this.btnCerrarPedido.Location = new System.Drawing.Point(1516, 938);
            this.btnCerrarPedido.Name = "btnCerrarPedido";
            this.btnCerrarPedido.Size = new System.Drawing.Size(335, 60);
            this.btnCerrarPedido.TabIndex = 24;
            this.btnCerrarPedido.Text = "RESUME";
            this.btnCerrarPedido.UseVisualStyleBackColor = false;
            // 
            // rbtnBrownie
            // 
            this.rbtnBrownie.AutoSize = true;
            this.rbtnBrownie.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnBrownie.Location = new System.Drawing.Point(75, 104);
            this.rbtnBrownie.Name = "rbtnBrownie";
            this.rbtnBrownie.Size = new System.Drawing.Size(160, 48);
            this.rbtnBrownie.TabIndex = 25;
            this.rbtnBrownie.TabStop = true;
            this.rbtnBrownie.Text = "Brownie";
            this.rbtnBrownie.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnCookies);
            this.groupBox1.Controls.Add(this.rbtnChococheese);
            this.groupBox1.Controls.Add(this.rbtnVulcano);
            this.groupBox1.Controls.Add(this.rbtnHeladoPeanut);
            this.groupBox1.Controls.Add(this.rbtnHeladoBrownie);
            this.groupBox1.Controls.Add(this.rbtnHeladoCookies);
            this.groupBox1.Controls.Add(this.rbtnHeladoTartaFresa);
            this.groupBox1.Controls.Add(this.rbtnTartaChocolate);
            this.groupBox1.Controls.Add(this.rbtnBrownie);
            this.groupBox1.Location = new System.Drawing.Point(271, 279);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1320, 489);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            // 
            // rbtnTartaChocolate
            // 
            this.rbtnTartaChocolate.AutoSize = true;
            this.rbtnTartaChocolate.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnTartaChocolate.Location = new System.Drawing.Point(970, 307);
            this.rbtnTartaChocolate.Name = "rbtnTartaChocolate";
            this.rbtnTartaChocolate.Size = new System.Drawing.Size(260, 48);
            this.rbtnTartaChocolate.TabIndex = 26;
            this.rbtnTartaChocolate.TabStop = true;
            this.rbtnTartaChocolate.Text = "TartaChocolate";
            this.rbtnTartaChocolate.UseVisualStyleBackColor = true;
            // 
            // rbtnHeladoTartaFresa
            // 
            this.rbtnHeladoTartaFresa.AutoSize = true;
            this.rbtnHeladoTartaFresa.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHeladoTartaFresa.Location = new System.Drawing.Point(970, 205);
            this.rbtnHeladoTartaFresa.Name = "rbtnHeladoTartaFresa";
            this.rbtnHeladoTartaFresa.Size = new System.Drawing.Size(299, 48);
            this.rbtnHeladoTartaFresa.TabIndex = 27;
            this.rbtnHeladoTartaFresa.TabStop = true;
            this.rbtnHeladoTartaFresa.Text = "HeladoTartaFresa";
            this.rbtnHeladoTartaFresa.UseVisualStyleBackColor = true;
            // 
            // rbtnHeladoCookies
            // 
            this.rbtnHeladoCookies.AutoSize = true;
            this.rbtnHeladoCookies.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHeladoCookies.Location = new System.Drawing.Point(970, 104);
            this.rbtnHeladoCookies.Name = "rbtnHeladoCookies";
            this.rbtnHeladoCookies.Size = new System.Drawing.Size(261, 48);
            this.rbtnHeladoCookies.TabIndex = 28;
            this.rbtnHeladoCookies.TabStop = true;
            this.rbtnHeladoCookies.Text = "HeladoCookies";
            this.rbtnHeladoCookies.UseVisualStyleBackColor = true;
            // 
            // rbtnHeladoBrownie
            // 
            this.rbtnHeladoBrownie.AutoSize = true;
            this.rbtnHeladoBrownie.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHeladoBrownie.Location = new System.Drawing.Point(512, 307);
            this.rbtnHeladoBrownie.Name = "rbtnHeladoBrownie";
            this.rbtnHeladoBrownie.Size = new System.Drawing.Size(264, 48);
            this.rbtnHeladoBrownie.TabIndex = 29;
            this.rbtnHeladoBrownie.TabStop = true;
            this.rbtnHeladoBrownie.Text = "HeladoBrownie";
            this.rbtnHeladoBrownie.UseVisualStyleBackColor = true;
            // 
            // rbtnHeladoPeanut
            // 
            this.rbtnHeladoPeanut.AutoSize = true;
            this.rbtnHeladoPeanut.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHeladoPeanut.Location = new System.Drawing.Point(512, 205);
            this.rbtnHeladoPeanut.Name = "rbtnHeladoPeanut";
            this.rbtnHeladoPeanut.Size = new System.Drawing.Size(247, 48);
            this.rbtnHeladoPeanut.TabIndex = 30;
            this.rbtnHeladoPeanut.TabStop = true;
            this.rbtnHeladoPeanut.Text = "HeladoPeanut";
            this.rbtnHeladoPeanut.UseVisualStyleBackColor = true;
            // 
            // rbtnVulcano
            // 
            this.rbtnVulcano.AutoSize = true;
            this.rbtnVulcano.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnVulcano.Location = new System.Drawing.Point(512, 104);
            this.rbtnVulcano.Name = "rbtnVulcano";
            this.rbtnVulcano.Size = new System.Drawing.Size(157, 48);
            this.rbtnVulcano.TabIndex = 31;
            this.rbtnVulcano.TabStop = true;
            this.rbtnVulcano.Text = "Vulcano";
            this.rbtnVulcano.UseVisualStyleBackColor = true;
            // 
            // rbtnChococheese
            // 
            this.rbtnChococheese.AutoSize = true;
            this.rbtnChococheese.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChococheese.Location = new System.Drawing.Point(75, 307);
            this.rbtnChococheese.Name = "rbtnChococheese";
            this.rbtnChococheese.Size = new System.Drawing.Size(237, 48);
            this.rbtnChococheese.TabIndex = 32;
            this.rbtnChococheese.TabStop = true;
            this.rbtnChococheese.Text = "Chococheese";
            this.rbtnChococheese.UseVisualStyleBackColor = true;
            // 
            // rbtnCookies
            // 
            this.rbtnCookies.AutoSize = true;
            this.rbtnCookies.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCookies.Location = new System.Drawing.Point(75, 205);
            this.rbtnCookies.Name = "rbtnCookies";
            this.rbtnCookies.Size = new System.Drawing.Size(157, 48);
            this.rbtnCookies.TabIndex = 33;
            this.rbtnCookies.TabStop = true;
            this.rbtnCookies.Text = "Cookies";
            this.rbtnCookies.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.BackgroundImage = global::TOP_Manage.Properties.Resources.correcto__2_;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(53, 910);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 88);
            this.button4.TabIndex = 23;
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // FrmPostre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnCerrarPedido);
            this.Controls.Add(this.button4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FrmPostre";
            this.Text = "Form10";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCerrarPedido;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RadioButton rbtnBrownie;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnCookies;
        private System.Windows.Forms.RadioButton rbtnChococheese;
        private System.Windows.Forms.RadioButton rbtnVulcano;
        private System.Windows.Forms.RadioButton rbtnHeladoPeanut;
        private System.Windows.Forms.RadioButton rbtnHeladoBrownie;
        private System.Windows.Forms.RadioButton rbtnHeladoCookies;
        private System.Windows.Forms.RadioButton rbtnHeladoTartaFresa;
        private System.Windows.Forms.RadioButton rbtnTartaChocolate;
    }
}