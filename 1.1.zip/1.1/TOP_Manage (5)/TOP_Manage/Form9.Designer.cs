﻿namespace TOP_Manage
{
    partial class FrmPedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerPedido = new System.Windows.Forms.Button();
            this.btnComedor = new System.Windows.Forms.Button();
            this.btnDomicilio = new System.Windows.Forms.Button();
            this.btnParaLlevar = new System.Windows.Forms.Button();
            this.btnCerrarPedido = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnVerPedido
            // 
            this.btnVerPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(64)))), ((int)(((byte)(89)))));
            this.btnVerPedido.FlatAppearance.BorderSize = 0;
            this.btnVerPedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnVerPedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnVerPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerPedido.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnVerPedido.ForeColor = System.Drawing.Color.White;
            this.btnVerPedido.Location = new System.Drawing.Point(948, 550);
            this.btnVerPedido.Name = "btnVerPedido";
            this.btnVerPedido.Size = new System.Drawing.Size(494, 272);
            this.btnVerPedido.TabIndex = 14;
            this.btnVerPedido.Text = "DRINK";
            this.btnVerPedido.UseVisualStyleBackColor = false;
            // 
            // btnComedor
            // 
            this.btnComedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(114)))), ((int)(((byte)(139)))));
            this.btnComedor.FlatAppearance.BorderSize = 0;
            this.btnComedor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnComedor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnComedor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComedor.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnComedor.ForeColor = System.Drawing.Color.White;
            this.btnComedor.Location = new System.Drawing.Point(393, 550);
            this.btnComedor.Name = "btnComedor";
            this.btnComedor.Size = new System.Drawing.Size(494, 272);
            this.btnComedor.TabIndex = 13;
            this.btnComedor.Text = "DESSERT";
            this.btnComedor.UseVisualStyleBackColor = false;
            // 
            // btnDomicilio
            // 
            this.btnDomicilio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(164)))), ((int)(((byte)(189)))));
            this.btnDomicilio.FlatAppearance.BorderSize = 0;
            this.btnDomicilio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnDomicilio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnDomicilio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDomicilio.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnDomicilio.ForeColor = System.Drawing.Color.White;
            this.btnDomicilio.Location = new System.Drawing.Point(948, 220);
            this.btnDomicilio.Name = "btnDomicilio";
            this.btnDomicilio.Size = new System.Drawing.Size(494, 272);
            this.btnDomicilio.TabIndex = 12;
            this.btnDomicilio.Text = "STARTER";
            this.btnDomicilio.UseVisualStyleBackColor = false;
            // 
            // btnParaLlevar
            // 
            this.btnParaLlevar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(194)))), ((int)(((byte)(209)))));
            this.btnParaLlevar.FlatAppearance.BorderSize = 0;
            this.btnParaLlevar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnParaLlevar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnParaLlevar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParaLlevar.Font = new System.Drawing.Font("Yu Gothic Light", 30F);
            this.btnParaLlevar.ForeColor = System.Drawing.Color.White;
            this.btnParaLlevar.Location = new System.Drawing.Point(393, 220);
            this.btnParaLlevar.Name = "btnParaLlevar";
            this.btnParaLlevar.Size = new System.Drawing.Size(494, 272);
            this.btnParaLlevar.TabIndex = 11;
            this.btnParaLlevar.Text = "PIZZA";
            this.btnParaLlevar.UseVisualStyleBackColor = false;
            // 
            // btnCerrarPedido
            // 
            this.btnCerrarPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnCerrarPedido.FlatAppearance.BorderSize = 0;
            this.btnCerrarPedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnCerrarPedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnCerrarPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarPedido.Font = new System.Drawing.Font("Yu Gothic Light", 17F);
            this.btnCerrarPedido.ForeColor = System.Drawing.Color.White;
            this.btnCerrarPedido.Location = new System.Drawing.Point(1506, 924);
            this.btnCerrarPedido.Name = "btnCerrarPedido";
            this.btnCerrarPedido.Size = new System.Drawing.Size(335, 60);
            this.btnCerrarPedido.TabIndex = 22;
            this.btnCerrarPedido.Text = "RESUME";
            this.btnCerrarPedido.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.BackgroundImage = global::TOP_Manage.Properties.Resources.correcto__2_;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.button4.ForeColor = System.Drawing.Color.Red;
            this.button4.Location = new System.Drawing.Point(25, 924);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 88);
            this.button4.TabIndex = 21;
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // FrmPedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.btnCerrarPedido);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnVerPedido);
            this.Controls.Add(this.btnComedor);
            this.Controls.Add(this.btnDomicilio);
            this.Controls.Add(this.btnParaLlevar);
            this.Name = "FrmPedido";
            this.Text = "Form9";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerPedido;
        private System.Windows.Forms.Button btnComedor;
        private System.Windows.Forms.Button btnDomicilio;
        private System.Windows.Forms.Button btnParaLlevar;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnCerrarPedido;
    }
}