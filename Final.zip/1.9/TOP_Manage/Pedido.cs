﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace TOP_Manage
{
    class Pedido
    {
        private int numPedido, mesa = 0;
        private string nombre = null;
        private CodigoDescuento codDesc = null;
        private Cliente cliente = null;
        private DateTime fecha;
        private double precio;
        private bool cancelado = false, pagado = false;
        private string nomCamarero;
        List<LineaPedido> lineasPedido = new List<LineaPedido>();

        public int NumPedido { get { return numPedido; } }
        public string NomCamarero { get { return nomCamarero; } }
        public CodigoDescuento CodDesc { get { return codDesc; } set { codDesc = value; } }
        public DateTime Fecha { get { return fecha; } }
        public double Precio { get { return precio; } }
        public bool Cancelado { get { return cancelado; } }
        public bool Pagado { get { return pagado; } }
        public List<LineaPedido> LineasPedido { get { return lineasPedido; } }
        public Cliente Cliente { get { return cliente; } set { cliente = value; } }
        public int Mesa { get { return mesa; } set { mesa = value; } }
        public string Nombre { get { return nombre; } set { nombre = value; } }

        public Pedido(string nomCam)
        {
            nomCamarero = nomCam;
            fecha = DateTime.Now;
        }

        public Pedido(int nPed, double prec, DateTime fech, bool canc, string nomCam, List<LineaPedido> lineasPed, bool pagdo)
        {
            numPedido = nPed;
            precio = prec;
            fecha = fech;
            cancelado = canc;
            nomCamarero = nomCam;
            lineasPedido = lineasPed;
            pagado = pagdo;
        }

        private bool ExisteLinea(LineaPedido linea)
        {
            foreach (LineaPedido lin in lineasPedido)
            {
                if (lin.Producto.Detalle == linea.Producto.Detalle)
                {
                    return true;
                }
            }
            return false;
        }


        public void AgregarLinea(LineaPedido linea)
        {
            if (!ExisteLinea(linea))
            {
                lineasPedido.Add(linea);
            }
            else
            {
                foreach (LineaPedido lin in lineasPedido)
                {
                    if (lin.Producto.Detalle == linea.Producto.Detalle)
                    {
                        lin.Cant += linea.Cant;
                    }
                }
            }
        }

        public static void SetPagado(MySqlConnection conexion, int nPed)
        {
            string consulta = "UPDATE pedidos SET pagado = true WHERE numPedido = " + nPed;
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            try
            {
                comando.ExecuteNonQuery();
            }
            catch (MySqlException)
            {
                throw;
            }
        }

        public static void SetCancelado(MySqlConnection conexion, int nPed)
        {
            string consulta = "UPDATE pedidos SET cancelado = true WHERE numPedido = " + nPed;
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            try
            {
                comando.ExecuteNonQuery();
            }
            catch (MySqlException)
            {
                throw;
            }
        }


        public static Pedido GetPedido(MySqlConnection conexion, int nPed)
        {
            string consulta = string.Format("SELECT * FROM pedidos WHERE numPedido = {0}", nPed);
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            Pedido pedido = null;
            MySqlDataReader reader = null;
            try
            {
                bool hayCliente = false;
                bool hayCodDesc = false;
                string tlfCli = "";
                string idDesc = "";
                List<LineaPedido> lineas = LineaPedido.GetLineas(conexion, nPed);
                reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    pedido = new Pedido(reader.GetInt32(0), reader.GetDouble(6), reader.GetDateTime(2), reader.GetBoolean(8), reader.GetString(1), lineas, reader.GetBoolean(9));
                    if (!reader.IsDBNull(3))
                    {
                        pedido.Mesa = reader.GetInt32(3);
                    }
                    if (!reader.IsDBNull(4))
                    {
                        hayCliente = true;
                        tlfCli = reader.GetString(4);
                    }
                    if (!reader.IsDBNull(5))
                    {
                        pedido.Nombre = reader.GetString(5);
                    }
                    if (!reader.IsDBNull(7))
                    {
                        hayCodDesc = true;
                        idDesc = reader.GetString(7);
                    }
                }
                reader.Close();
                if (hayCliente)
                {
                    pedido.Cliente = Cliente.GetCliente(tlfCli, conexion);
                }
                if (hayCodDesc)
                {
                    pedido.codDesc = CodigoDescuento.GetCodigoDescuento(idDesc, conexion);
                }
            }
            catch (MySqlException)
            {
                throw;
            }
            finally
            {
                reader.Close();
            }
            return pedido;
        }

        public static int GetUltNumPed(MySqlConnection conexion)
        {
            string consulta = "SELECT * FROM pedidos ORDER BY numPedido DESC;";
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            int nPed = 0;
            try
            {
                MySqlDataReader reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    nPed = reader.GetInt32(0);
                }
                reader.Close();
            }
            catch (MySqlException)
            {
                throw;
            }
            return nPed;
        }

        public static void AgregarPedido(MySqlConnection conexion, Pedido pedido)
        {
            string tlf, desc, nombre, mesa;
            if (pedido.Cliente == null)
            {
                tlf = "null";
            }
            else
            {
                tlf = "'" + pedido.Cliente.Tlf + "'";
            }
            if (pedido.CodDesc == null)
            {
                desc = "null";
            }
            else
            {
                desc = "'" + pedido.CodDesc.Id + "'";
            }
            if (pedido.Nombre == null)
            {
                nombre = "null";
            }
            else
            {
                nombre =  "'"+pedido.Nombre+"'";
            }
            if (pedido.Mesa == 0)
            {
                mesa = "null";
            }
            else
            {
                mesa = pedido.Mesa.ToString();
            }
            string insertPedido = string.Format("INSERT INTO pedidos VALUES (null, '{0}', '{1}', {2}, {3}, {4}, {5}, {6}, {7}, {8});", pedido.NomCamarero, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), mesa, tlf, nombre, pedido.GetPrecio().ToString().Replace(",", "."), desc, pedido.Cancelado, pedido.Pagado);
            MySqlCommand insertPed = new MySqlCommand(insertPedido, conexion);
            try
            {
                if (pedido.Cliente != null)
                {
                    if (Cliente.GetCliente(pedido.Cliente.Tlf, conexion) == null)
                    {
                        Cliente.AgregarCliente(conexion, pedido.Cliente);
                    }
                }
                insertPed.ExecuteNonQuery();
                if (pedido.Cliente != null)
                {
                    if (!Cliente.SonClientesIguales(pedido.Cliente, Cliente.GetCliente(pedido.Cliente.Tlf, conexion)))
                    {
                        Cliente.Update(conexion, pedido.Cliente);
                    }
                }
                int nPed = GetUltNumPed(conexion);
                foreach (LineaPedido linea in pedido.LineasPedido)
                {
                    string insertLinea = string.Format("INSERT INTO lineaPedido VALUES (NULL, {0}, {1}, {2}, {3});", nPed, Producto.GetId(linea.Producto.Detalle, conexion), linea.Cant, linea.Hecha);
                    MySqlCommand comando = new MySqlCommand(insertLinea, conexion);
                    comando.ExecuteNonQuery();
                }
            }
            catch (MySqlException)
            {
                throw;
            }
        }

        public double GetPrecio()
        {
            double prec = 0;
            foreach (LineaPedido linea in this.LineasPedido)
            {
                prec += linea.Cant * linea.Producto.Precio;
            }
            if (codDesc == null)
            {
                return prec;
            }
            else
            {
                double descuento = CodDesc.Descuento;
                return prec * (1 - (descuento / 100));
            }
        }

        public string GetDestino()
        {
            if (this.cliente != null)
            {
                return string.Format("DESTINATION: {0}, {1}", this.Cliente.Calle, this.Cliente.Portal);
            }
            else if (this.Nombre != null)
            {
                return string.Format("DESTINATION: {0}", this.Nombre);
            }
            else
            {
                return string.Format("DESTINATION: Table {0}", this.Mesa);
            }
        }

        public static double GetCaja(MySqlConnection conexion, DateTime fecha)
        {
            string consulta = string.Format("SELECT numPedido FROM pedidos WHERE fecha = '{0}' AND pagado = true", fecha.ToString("yyyy-MM-dd"));
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            double caja = 0;
            List<int> nPedidos = new List<int>();
            List<Pedido> pedidos = new List<Pedido>();
            try
            {
                MySqlDataReader reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        nPedidos.Add(reader.GetInt32(0));
                    }
                }
                reader.Close();
                foreach (int nPed in nPedidos)
                {
                    pedidos.Add(GetPedido(conexion, nPed));
                }
                foreach (Pedido pedido in pedidos)
                {
                    caja += pedido.GetPrecio();
                }
            }
            catch (MySqlException)
            {
                throw;
            }
            return caja;
        }

        public static List<Pedido> GetPedidosNoPagados(MySqlConnection conexion)
        {
            string consulta = string.Format("SELECT numPedido FROM pedidos WHERE pagado = false AND fecha = '{0}' AND cancelado = false", DateTime.Now.ToString("yyyy-MM-dd")); ;
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            List<Pedido> pedidos = new List<Pedido>();
            List<int> nPedidos = new List<int>();
            try
            {
                MySqlDataReader reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        nPedidos.Add(reader.GetInt32(0));
                    }
                }
                reader.Close();
                foreach (int nPed in nPedidos)
                {
                    pedidos.Add(Pedido.GetPedido(conexion, nPed));
                }
            }
            catch (MySqlException)
            {
                throw;
            }
            return pedidos;
        }

        public static List<Pedido> GetPedidosHoy(MySqlConnection conexion)
        {
            string consulta = string.Format("SELECT numPedido FROM pedidos WHERE fecha = '{0}'", DateTime.Now.ToString("yyyy-MM--dd"));
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            List<Pedido> pedidos = new List<Pedido>();
            List<int> nPedidos = new List<int>();
            MySqlDataReader reader = null;
            try
            {
                reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        nPedidos.Add(reader.GetInt32(0));
                    }
                }
                reader.Close();
                foreach (int nPed in nPedidos)
                {
                    pedidos.Add(Pedido.GetPedido(conexion, nPed));
                }
            }
            catch (MySqlException)
            {
                throw;
            }
            finally
            {
                reader.Close();
            }
            return pedidos;
        }
    }
}