﻿namespace TOP_Manage
{
    partial class FrmBebida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbxBebidas = new System.Windows.Forms.GroupBox();
            this.rbtnagua50cl = new System.Windows.Forms.RadioButton();
            this.rbtnagua1L = new System.Windows.Forms.RadioButton();
            this.rbtnagua2L = new System.Windows.Forms.RadioButton();
            this.rbtnFLimon50cl = new System.Windows.Forms.RadioButton();
            this.rbtnFLimon1L = new System.Windows.Forms.RadioButton();
            this.rbtnFLimon2L = new System.Windows.Forms.RadioButton();
            this.rbtnLataFNaranja = new System.Windows.Forms.RadioButton();
            this.rbtnLataFLimon = new System.Windows.Forms.RadioButton();
            this.rbtnCocacola50cl = new System.Windows.Forms.RadioButton();
            this.rbtnCocaCola1L = new System.Windows.Forms.RadioButton();
            this.rbtnCocaCola2L = new System.Windows.Forms.RadioButton();
            this.rbtnFNaranja50cl = new System.Windows.Forms.RadioButton();
            this.rbtnFNaranja1L = new System.Windows.Forms.RadioButton();
            this.rbtnFNaranja2L = new System.Windows.Forms.RadioButton();
            this.rbtnLataCocaCola = new System.Windows.Forms.RadioButton();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblNomCamarero = new System.Windows.Forms.Label();
            this.nudCant = new System.Windows.Forms.NumericUpDown();
            this.errorBebidas = new System.Windows.Forms.ErrorProvider(this.components);
            this.gbxBebidas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBebidas)).BeginInit();
            this.SuspendLayout();
            // 
            // gbxBebidas
            // 
            this.gbxBebidas.Controls.Add(this.rbtnagua50cl);
            this.gbxBebidas.Controls.Add(this.rbtnagua1L);
            this.gbxBebidas.Controls.Add(this.rbtnagua2L);
            this.gbxBebidas.Controls.Add(this.rbtnFLimon50cl);
            this.gbxBebidas.Controls.Add(this.rbtnFLimon1L);
            this.gbxBebidas.Controls.Add(this.rbtnFLimon2L);
            this.gbxBebidas.Controls.Add(this.rbtnLataFNaranja);
            this.gbxBebidas.Controls.Add(this.rbtnLataFLimon);
            this.gbxBebidas.Controls.Add(this.rbtnCocacola50cl);
            this.gbxBebidas.Controls.Add(this.rbtnCocaCola1L);
            this.gbxBebidas.Controls.Add(this.rbtnCocaCola2L);
            this.gbxBebidas.Controls.Add(this.rbtnFNaranja50cl);
            this.gbxBebidas.Controls.Add(this.rbtnFNaranja1L);
            this.gbxBebidas.Controls.Add(this.rbtnFNaranja2L);
            this.gbxBebidas.Controls.Add(this.rbtnLataCocaCola);
            this.gbxBebidas.Location = new System.Drawing.Point(134, 341);
            this.gbxBebidas.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxBebidas.Name = "gbxBebidas";
            this.gbxBebidas.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxBebidas.Size = new System.Drawing.Size(1811, 611);
            this.gbxBebidas.TabIndex = 29;
            this.gbxBebidas.TabStop = false;
            // 
            // rbtnagua50cl
            // 
            this.rbtnagua50cl.AutoSize = true;
            this.rbtnagua50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua50cl.Location = new System.Drawing.Point(1443, 130);
            this.rbtnagua50cl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnagua50cl.Name = "rbtnagua50cl";
            this.rbtnagua50cl.Size = new System.Drawing.Size(218, 56);
            this.rbtnagua50cl.TabIndex = 39;
            this.rbtnagua50cl.TabStop = true;
            this.rbtnagua50cl.Text = "Water50cl";
            this.rbtnagua50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnagua1L
            // 
            this.rbtnagua1L.AutoSize = true;
            this.rbtnagua1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua1L.Location = new System.Drawing.Point(1443, 256);
            this.rbtnagua1L.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnagua1L.Name = "rbtnagua1L";
            this.rbtnagua1L.Size = new System.Drawing.Size(192, 56);
            this.rbtnagua1L.TabIndex = 38;
            this.rbtnagua1L.TabStop = true;
            this.rbtnagua1L.Text = "Water1L";
            this.rbtnagua1L.UseVisualStyleBackColor = true;
            // 
            // rbtnagua2L
            // 
            this.rbtnagua2L.AutoSize = true;
            this.rbtnagua2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnagua2L.Location = new System.Drawing.Point(1443, 384);
            this.rbtnagua2L.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnagua2L.Name = "rbtnagua2L";
            this.rbtnagua2L.Size = new System.Drawing.Size(192, 56);
            this.rbtnagua2L.TabIndex = 37;
            this.rbtnagua2L.TabStop = true;
            this.rbtnagua2L.Text = "Water2L";
            this.rbtnagua2L.UseVisualStyleBackColor = true;
            // 
            // rbtnFLimon50cl
            // 
            this.rbtnFLimon50cl.AutoSize = true;
            this.rbtnFLimon50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFLimon50cl.Location = new System.Drawing.Point(1083, 130);
            this.rbtnFLimon50cl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnFLimon50cl.Name = "rbtnFLimon50cl";
            this.rbtnFLimon50cl.Size = new System.Drawing.Size(261, 56);
            this.rbtnFLimon50cl.TabIndex = 36;
            this.rbtnFLimon50cl.TabStop = true;
            this.rbtnFLimon50cl.Text = "FLemon50cl";
            this.rbtnFLimon50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnFLimon1L
            // 
            this.rbtnFLimon1L.AutoSize = true;
            this.rbtnFLimon1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFLimon1L.Location = new System.Drawing.Point(1083, 256);
            this.rbtnFLimon1L.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnFLimon1L.Name = "rbtnFLimon1L";
            this.rbtnFLimon1L.Size = new System.Drawing.Size(235, 56);
            this.rbtnFLimon1L.TabIndex = 35;
            this.rbtnFLimon1L.TabStop = true;
            this.rbtnFLimon1L.Text = "FLemon1L";
            this.rbtnFLimon1L.UseVisualStyleBackColor = true;
            // 
            // rbtnFLimon2L
            // 
            this.rbtnFLimon2L.AutoSize = true;
            this.rbtnFLimon2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFLimon2L.Location = new System.Drawing.Point(1083, 384);
            this.rbtnFLimon2L.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnFLimon2L.Name = "rbtnFLimon2L";
            this.rbtnFLimon2L.Size = new System.Drawing.Size(235, 56);
            this.rbtnFLimon2L.TabIndex = 34;
            this.rbtnFLimon2L.TabStop = true;
            this.rbtnFLimon2L.Text = "FLemon2L";
            this.rbtnFLimon2L.UseVisualStyleBackColor = true;
            // 
            // rbtnLataFNaranja
            // 
            this.rbtnLataFNaranja.AutoSize = true;
            this.rbtnLataFNaranja.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnLataFNaranja.Location = new System.Drawing.Point(84, 256);
            this.rbtnLataFNaranja.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnLataFNaranja.Name = "rbtnLataFNaranja";
            this.rbtnLataFNaranja.Size = new System.Drawing.Size(264, 56);
            this.rbtnLataFNaranja.TabIndex = 33;
            this.rbtnLataFNaranja.TabStop = true;
            this.rbtnLataFNaranja.Text = "FOrangeCan";
            this.rbtnLataFNaranja.UseVisualStyleBackColor = true;
            // 
            // rbtnLataFLimon
            // 
            this.rbtnLataFLimon.AutoSize = true;
            this.rbtnLataFLimon.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnLataFLimon.Location = new System.Drawing.Point(84, 384);
            this.rbtnLataFLimon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnLataFLimon.Name = "rbtnLataFLimon";
            this.rbtnLataFLimon.Size = new System.Drawing.Size(260, 56);
            this.rbtnLataFLimon.TabIndex = 32;
            this.rbtnLataFLimon.TabStop = true;
            this.rbtnLataFLimon.Text = "FLemonCan";
            this.rbtnLataFLimon.UseVisualStyleBackColor = true;
            // 
            // rbtnCocacola50cl
            // 
            this.rbtnCocacola50cl.AutoSize = true;
            this.rbtnCocacola50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCocacola50cl.Location = new System.Drawing.Point(400, 130);
            this.rbtnCocacola50cl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnCocacola50cl.Name = "rbtnCocacola50cl";
            this.rbtnCocacola50cl.Size = new System.Drawing.Size(282, 56);
            this.rbtnCocacola50cl.TabIndex = 31;
            this.rbtnCocacola50cl.TabStop = true;
            this.rbtnCocacola50cl.Text = "CocaCola50cl";
            this.rbtnCocacola50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnCocaCola1L
            // 
            this.rbtnCocaCola1L.AutoSize = true;
            this.rbtnCocaCola1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCocaCola1L.Location = new System.Drawing.Point(400, 256);
            this.rbtnCocaCola1L.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnCocaCola1L.Name = "rbtnCocaCola1L";
            this.rbtnCocaCola1L.Size = new System.Drawing.Size(256, 56);
            this.rbtnCocaCola1L.TabIndex = 30;
            this.rbtnCocaCola1L.TabStop = true;
            this.rbtnCocaCola1L.Text = "CocaCola1L";
            this.rbtnCocaCola1L.UseVisualStyleBackColor = true;
            // 
            // rbtnCocaCola2L
            // 
            this.rbtnCocaCola2L.AutoSize = true;
            this.rbtnCocaCola2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCocaCola2L.Location = new System.Drawing.Point(400, 384);
            this.rbtnCocaCola2L.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnCocaCola2L.Name = "rbtnCocaCola2L";
            this.rbtnCocaCola2L.Size = new System.Drawing.Size(256, 56);
            this.rbtnCocaCola2L.TabIndex = 29;
            this.rbtnCocaCola2L.TabStop = true;
            this.rbtnCocaCola2L.Text = "CocaCola2L";
            this.rbtnCocaCola2L.UseVisualStyleBackColor = true;
            // 
            // rbtnFNaranja50cl
            // 
            this.rbtnFNaranja50cl.AutoSize = true;
            this.rbtnFNaranja50cl.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFNaranja50cl.Location = new System.Drawing.Point(722, 130);
            this.rbtnFNaranja50cl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnFNaranja50cl.Name = "rbtnFNaranja50cl";
            this.rbtnFNaranja50cl.Size = new System.Drawing.Size(265, 56);
            this.rbtnFNaranja50cl.TabIndex = 28;
            this.rbtnFNaranja50cl.TabStop = true;
            this.rbtnFNaranja50cl.Text = "FOrange50cl";
            this.rbtnFNaranja50cl.UseVisualStyleBackColor = true;
            // 
            // rbtnFNaranja1L
            // 
            this.rbtnFNaranja1L.AutoSize = true;
            this.rbtnFNaranja1L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFNaranja1L.Location = new System.Drawing.Point(722, 256);
            this.rbtnFNaranja1L.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnFNaranja1L.Name = "rbtnFNaranja1L";
            this.rbtnFNaranja1L.Size = new System.Drawing.Size(239, 56);
            this.rbtnFNaranja1L.TabIndex = 27;
            this.rbtnFNaranja1L.TabStop = true;
            this.rbtnFNaranja1L.Text = "FOrange1L";
            this.rbtnFNaranja1L.UseVisualStyleBackColor = true;
            // 
            // rbtnFNaranja2L
            // 
            this.rbtnFNaranja2L.AutoSize = true;
            this.rbtnFNaranja2L.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnFNaranja2L.Location = new System.Drawing.Point(722, 384);
            this.rbtnFNaranja2L.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnFNaranja2L.Name = "rbtnFNaranja2L";
            this.rbtnFNaranja2L.Size = new System.Drawing.Size(239, 56);
            this.rbtnFNaranja2L.TabIndex = 26;
            this.rbtnFNaranja2L.TabStop = true;
            this.rbtnFNaranja2L.Text = "FOrange2L";
            this.rbtnFNaranja2L.UseVisualStyleBackColor = true;
            // 
            // rbtnLataCocaCola
            // 
            this.rbtnLataCocaCola.AutoSize = true;
            this.rbtnLataCocaCola.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnLataCocaCola.Location = new System.Drawing.Point(84, 130);
            this.rbtnLataCocaCola.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnLataCocaCola.Name = "rbtnLataCocaCola";
            this.rbtnLataCocaCola.Size = new System.Drawing.Size(281, 56);
            this.rbtnLataCocaCola.TabIndex = 25;
            this.rbtnLataCocaCola.TabStop = true;
            this.rbtnLataCocaCola.Text = "CocaColaCan";
            this.rbtnLataCocaCola.UseVisualStyleBackColor = true;
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnAgregar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Yu Gothic Light", 17F);
            this.btnAgregar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(194)))), ((int)(((byte)(209)))));
            this.btnAgregar.Location = new System.Drawing.Point(1692, 1165);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(377, 75);
            this.btnAgregar.TabIndex = 28;
            this.btnAgregar.Text = "ADD";
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.BackgroundImage = global::TOP_Manage.Properties.Resources.proximo;
            this.btnReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturn.FlatAppearance.BorderSize = 0;
            this.btnReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturn.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.btnReturn.ForeColor = System.Drawing.Color.Red;
            this.btnReturn.Location = new System.Drawing.Point(46, 1130);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(98, 110);
            this.btnReturn.TabIndex = 27;
            this.btnReturn.UseCompatibleTextRendering = true;
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // lblNomCamarero
            // 
            this.lblNomCamarero.AutoSize = true;
            this.lblNomCamarero.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.lblNomCamarero.Location = new System.Drawing.Point(2005, 11);
            this.lblNomCamarero.Name = "lblNomCamarero";
            this.lblNomCamarero.Size = new System.Drawing.Size(126, 52);
            this.lblNomCamarero.TabIndex = 45;
            this.lblNomCamarero.Text = "label1";
            this.lblNomCamarero.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nudCant
            // 
            this.nudCant.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.nudCant.Location = new System.Drawing.Point(1509, 1165);
            this.nudCant.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudCant.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCant.Name = "nudCant";
            this.nudCant.Size = new System.Drawing.Size(120, 72);
            this.nudCant.TabIndex = 47;
            this.nudCant.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // errorBebidas
            // 
            this.errorBebidas.ContainerControl = this;
            // 
            // FrmBebida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(2140, 1291);
            this.Controls.Add(this.nudCant);
            this.Controls.Add(this.lblNomCamarero);
            this.Controls.Add(this.gbxBebidas);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnReturn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmBebida";
            this.Text = "Form11";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmBebida_Load);
            this.gbxBebidas.ResumeLayout(false);
            this.gbxBebidas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBebidas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxBebidas;
        private System.Windows.Forms.RadioButton rbtnLataFNaranja;
        private System.Windows.Forms.RadioButton rbtnLataFLimon;
        private System.Windows.Forms.RadioButton rbtnCocacola50cl;
        private System.Windows.Forms.RadioButton rbtnCocaCola1L;
        private System.Windows.Forms.RadioButton rbtnCocaCola2L;
        private System.Windows.Forms.RadioButton rbtnFNaranja50cl;
        private System.Windows.Forms.RadioButton rbtnFNaranja1L;
        private System.Windows.Forms.RadioButton rbtnFNaranja2L;
        private System.Windows.Forms.RadioButton rbtnLataCocaCola;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.RadioButton rbtnagua50cl;
        private System.Windows.Forms.RadioButton rbtnagua1L;
        private System.Windows.Forms.RadioButton rbtnagua2L;
        private System.Windows.Forms.RadioButton rbtnFLimon50cl;
        private System.Windows.Forms.RadioButton rbtnFLimon1L;
        private System.Windows.Forms.RadioButton rbtnFLimon2L;
        private System.Windows.Forms.Label lblNomCamarero;
        private System.Windows.Forms.NumericUpDown nudCant;
        private System.Windows.Forms.ErrorProvider errorBebidas;
    }
}