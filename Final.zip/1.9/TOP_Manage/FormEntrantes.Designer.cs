﻿namespace TOP_Manage
{
    partial class FrmEntrante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbxEntrantes = new System.Windows.Forms.GroupBox();
            this.rbtnChickenWingsCombo = new System.Windows.Forms.RadioButton();
            this.radio6GarlicCheeseBread = new System.Windows.Forms.RadioButton();
            this.rbtnChickenCombo = new System.Windows.Forms.RadioButton();
            this.rbtnChickenSalad = new System.Windows.Forms.RadioButton();
            this.rbtnCamembits = new System.Windows.Forms.RadioButton();
            this.rbtn6GarlicBread = new System.Windows.Forms.RadioButton();
            this.rbtnPotatoBacChees = new System.Windows.Forms.RadioButton();
            this.rbtnChickenWings = new System.Windows.Forms.RadioButton();
            this.rbtnCesarSalad = new System.Windows.Forms.RadioButton();
            this.rbtnChickenStrips = new System.Windows.Forms.RadioButton();
            this.rbtn4GarlicBread = new System.Windows.Forms.RadioButton();
            this.rbtnGroveSalad = new System.Windows.Forms.RadioButton();
            this.rbtnNuggets = new System.Windows.Forms.RadioButton();
            this.rbtn4GarlicCheeseBread = new System.Windows.Forms.RadioButton();
            this.rbtnPotatoes = new System.Windows.Forms.RadioButton();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnVolver = new System.Windows.Forms.Button();
            this.lblNomCamarero = new System.Windows.Forms.Label();
            this.nudCant = new System.Windows.Forms.NumericUpDown();
            this.errorEntrantes = new System.Windows.Forms.ErrorProvider(this.components);
            this.gbxEntrantes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorEntrantes)).BeginInit();
            this.SuspendLayout();
            // 
            // gbxEntrantes
            // 
            this.gbxEntrantes.Controls.Add(this.rbtnChickenWingsCombo);
            this.gbxEntrantes.Controls.Add(this.radio6GarlicCheeseBread);
            this.gbxEntrantes.Controls.Add(this.rbtnChickenCombo);
            this.gbxEntrantes.Controls.Add(this.rbtnChickenSalad);
            this.gbxEntrantes.Controls.Add(this.rbtnCamembits);
            this.gbxEntrantes.Controls.Add(this.rbtn6GarlicBread);
            this.gbxEntrantes.Controls.Add(this.rbtnPotatoBacChees);
            this.gbxEntrantes.Controls.Add(this.rbtnChickenWings);
            this.gbxEntrantes.Controls.Add(this.rbtnCesarSalad);
            this.gbxEntrantes.Controls.Add(this.rbtnChickenStrips);
            this.gbxEntrantes.Controls.Add(this.rbtn4GarlicBread);
            this.gbxEntrantes.Controls.Add(this.rbtnGroveSalad);
            this.gbxEntrantes.Controls.Add(this.rbtnNuggets);
            this.gbxEntrantes.Controls.Add(this.rbtn4GarlicCheeseBread);
            this.gbxEntrantes.Controls.Add(this.rbtnPotatoes);
            this.gbxEntrantes.Location = new System.Drawing.Point(142, 238);
            this.gbxEntrantes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxEntrantes.Name = "gbxEntrantes";
            this.gbxEntrantes.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxEntrantes.Size = new System.Drawing.Size(1811, 640);
            this.gbxEntrantes.TabIndex = 32;
            this.gbxEntrantes.TabStop = false;
            // 
            // rbtnChickenWingsCombo
            // 
            this.rbtnChickenWingsCombo.AutoSize = true;
            this.rbtnChickenWingsCombo.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenWingsCombo.Location = new System.Drawing.Point(1103, 469);
            this.rbtnChickenWingsCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnChickenWingsCombo.Name = "rbtnChickenWingsCombo";
            this.rbtnChickenWingsCombo.Size = new System.Drawing.Size(413, 56);
            this.rbtnChickenWingsCombo.TabIndex = 42;
            this.rbtnChickenWingsCombo.TabStop = true;
            this.rbtnChickenWingsCombo.Text = "ChickenWingsCombo";
            this.rbtnChickenWingsCombo.UseVisualStyleBackColor = true;
            // 
            // radio6GarlicCheeseBread
            // 
            this.radio6GarlicCheeseBread.AutoSize = true;
            this.radio6GarlicCheeseBread.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.radio6GarlicCheeseBread.Location = new System.Drawing.Point(271, 469);
            this.radio6GarlicCheeseBread.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio6GarlicCheeseBread.Name = "radio6GarlicCheeseBread";
            this.radio6GarlicCheeseBread.Size = new System.Drawing.Size(401, 56);
            this.radio6GarlicCheeseBread.TabIndex = 41;
            this.radio6GarlicCheeseBread.TabStop = true;
            this.radio6GarlicCheeseBread.Text = "6GarlicCheeseBread";
            this.radio6GarlicCheeseBread.UseVisualStyleBackColor = true;
            // 
            // rbtnChickenCombo
            // 
            this.rbtnChickenCombo.AutoSize = true;
            this.rbtnChickenCombo.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenCombo.Location = new System.Drawing.Point(731, 469);
            this.rbtnChickenCombo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnChickenCombo.Name = "rbtnChickenCombo";
            this.rbtnChickenCombo.Size = new System.Drawing.Size(309, 56);
            this.rbtnChickenCombo.TabIndex = 40;
            this.rbtnChickenCombo.TabStop = true;
            this.rbtnChickenCombo.Text = "ChickenCombo";
            this.rbtnChickenCombo.UseVisualStyleBackColor = true;
            // 
            // rbtnChickenSalad
            // 
            this.rbtnChickenSalad.AutoSize = true;
            this.rbtnChickenSalad.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenSalad.Location = new System.Drawing.Point(1262, 117);
            this.rbtnChickenSalad.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnChickenSalad.Name = "rbtnChickenSalad";
            this.rbtnChickenSalad.Size = new System.Drawing.Size(283, 56);
            this.rbtnChickenSalad.TabIndex = 36;
            this.rbtnChickenSalad.TabStop = true;
            this.rbtnChickenSalad.Text = "ChickenSalad";
            this.rbtnChickenSalad.UseVisualStyleBackColor = true;
            // 
            // rbtnCamembits
            // 
            this.rbtnCamembits.AutoSize = true;
            this.rbtnCamembits.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCamembits.Location = new System.Drawing.Point(1251, 231);
            this.rbtnCamembits.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnCamembits.Name = "rbtnCamembits";
            this.rbtnCamembits.Size = new System.Drawing.Size(244, 56);
            this.rbtnCamembits.TabIndex = 35;
            this.rbtnCamembits.TabStop = true;
            this.rbtnCamembits.Text = "Camembits";
            this.rbtnCamembits.UseVisualStyleBackColor = true;
            // 
            // rbtn6GarlicBread
            // 
            this.rbtn6GarlicBread.AutoSize = true;
            this.rbtn6GarlicBread.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtn6GarlicBread.Location = new System.Drawing.Point(1298, 348);
            this.rbtn6GarlicBread.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn6GarlicBread.Name = "rbtn6GarlicBread";
            this.rbtn6GarlicBread.Size = new System.Drawing.Size(271, 56);
            this.rbtn6GarlicBread.TabIndex = 34;
            this.rbtn6GarlicBread.TabStop = true;
            this.rbtn6GarlicBread.Text = "6GarlicBread";
            this.rbtn6GarlicBread.UseVisualStyleBackColor = true;
            // 
            // rbtnPotatoBacChees
            // 
            this.rbtnPotatoBacChees.AutoSize = true;
            this.rbtnPotatoBacChees.Font = new System.Drawing.Font("Yu Gothic Light", 19F);
            this.rbtnPotatoBacChees.Location = new System.Drawing.Point(352, 234);
            this.rbtnPotatoBacChees.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnPotatoBacChees.Name = "rbtnPotatoBacChees";
            this.rbtnPotatoBacChees.Size = new System.Drawing.Size(319, 53);
            this.rbtnPotatoBacChees.TabIndex = 33;
            this.rbtnPotatoBacChees.TabStop = true;
            this.rbtnPotatoBacChees.Text = "PotatoBacChees";
            this.rbtnPotatoBacChees.UseVisualStyleBackColor = true;
            // 
            // rbtnChickenWings
            // 
            this.rbtnChickenWings.AutoSize = true;
            this.rbtnChickenWings.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenWings.Location = new System.Drawing.Point(226, 348);
            this.rbtnChickenWings.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnChickenWings.Name = "rbtnChickenWings";
            this.rbtnChickenWings.Size = new System.Drawing.Size(290, 56);
            this.rbtnChickenWings.TabIndex = 32;
            this.rbtnChickenWings.TabStop = true;
            this.rbtnChickenWings.Text = "ChickenWings";
            this.rbtnChickenWings.UseVisualStyleBackColor = true;
            // 
            // rbtnCesarSalad
            // 
            this.rbtnCesarSalad.AutoSize = true;
            this.rbtnCesarSalad.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCesarSalad.Location = new System.Drawing.Point(579, 117);
            this.rbtnCesarSalad.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnCesarSalad.Name = "rbtnCesarSalad";
            this.rbtnCesarSalad.Size = new System.Drawing.Size(245, 56);
            this.rbtnCesarSalad.TabIndex = 31;
            this.rbtnCesarSalad.TabStop = true;
            this.rbtnCesarSalad.Text = "CesarSalad";
            this.rbtnCesarSalad.UseVisualStyleBackColor = true;
            // 
            // rbtnChickenStrips
            // 
            this.rbtnChickenStrips.AutoSize = true;
            this.rbtnChickenStrips.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChickenStrips.Location = new System.Drawing.Point(687, 234);
            this.rbtnChickenStrips.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnChickenStrips.Name = "rbtnChickenStrips";
            this.rbtnChickenStrips.Size = new System.Drawing.Size(285, 56);
            this.rbtnChickenStrips.TabIndex = 30;
            this.rbtnChickenStrips.TabStop = true;
            this.rbtnChickenStrips.Text = "ChickenStrips";
            this.rbtnChickenStrips.UseVisualStyleBackColor = true;
            // 
            // rbtn4GarlicBread
            // 
            this.rbtn4GarlicBread.AutoSize = true;
            this.rbtn4GarlicBread.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtn4GarlicBread.Location = new System.Drawing.Point(559, 348);
            this.rbtn4GarlicBread.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn4GarlicBread.Name = "rbtn4GarlicBread";
            this.rbtn4GarlicBread.Size = new System.Drawing.Size(271, 56);
            this.rbtn4GarlicBread.TabIndex = 29;
            this.rbtn4GarlicBread.TabStop = true;
            this.rbtn4GarlicBread.Text = "4GarlicBread";
            this.rbtn4GarlicBread.UseVisualStyleBackColor = true;
            // 
            // rbtnGroveSalad
            // 
            this.rbtnGroveSalad.AutoSize = true;
            this.rbtnGroveSalad.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnGroveSalad.Location = new System.Drawing.Point(901, 117);
            this.rbtnGroveSalad.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnGroveSalad.Name = "rbtnGroveSalad";
            this.rbtnGroveSalad.Size = new System.Drawing.Size(246, 56);
            this.rbtnGroveSalad.TabIndex = 28;
            this.rbtnGroveSalad.TabStop = true;
            this.rbtnGroveSalad.Text = "GroveSalad";
            this.rbtnGroveSalad.UseVisualStyleBackColor = true;
            // 
            // rbtnNuggets
            // 
            this.rbtnNuggets.AutoSize = true;
            this.rbtnNuggets.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnNuggets.Location = new System.Drawing.Point(1013, 234);
            this.rbtnNuggets.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnNuggets.Name = "rbtnNuggets";
            this.rbtnNuggets.Size = new System.Drawing.Size(191, 56);
            this.rbtnNuggets.TabIndex = 27;
            this.rbtnNuggets.TabStop = true;
            this.rbtnNuggets.Text = "Nuggets";
            this.rbtnNuggets.UseVisualStyleBackColor = true;
            // 
            // rbtn4GarlicCheeseBread
            // 
            this.rbtn4GarlicCheeseBread.AutoSize = true;
            this.rbtn4GarlicCheeseBread.Font = new System.Drawing.Font("Yu Gothic Light", 19F);
            this.rbtn4GarlicCheeseBread.Location = new System.Drawing.Point(880, 348);
            this.rbtn4GarlicCheeseBread.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn4GarlicCheeseBread.Name = "rbtn4GarlicCheeseBread";
            this.rbtn4GarlicCheeseBread.Size = new System.Drawing.Size(381, 53);
            this.rbtn4GarlicCheeseBread.TabIndex = 26;
            this.rbtn4GarlicCheeseBread.TabStop = true;
            this.rbtn4GarlicCheeseBread.Text = "4GarlicCheeseBread";
            this.rbtn4GarlicCheeseBread.UseVisualStyleBackColor = true;
            // 
            // rbtnPotatoes
            // 
            this.rbtnPotatoes.AutoSize = true;
            this.rbtnPotatoes.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnPotatoes.Location = new System.Drawing.Point(263, 117);
            this.rbtnPotatoes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnPotatoes.Name = "rbtnPotatoes";
            this.rbtnPotatoes.Size = new System.Drawing.Size(199, 56);
            this.rbtnPotatoes.TabIndex = 25;
            this.rbtnPotatoes.TabStop = true;
            this.rbtnPotatoes.Text = "Potatoes";
            this.rbtnPotatoes.UseVisualStyleBackColor = true;
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnAgregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnAgregar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Yu Gothic Light", 17F);
            this.btnAgregar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(194)))), ((int)(((byte)(209)))));
            this.btnAgregar.Location = new System.Drawing.Point(1695, 1166);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(377, 75);
            this.btnAgregar.TabIndex = 31;
            this.btnAgregar.Text = "ADD";
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnVolver
            // 
            this.btnVolver.BackColor = System.Drawing.Color.White;
            this.btnVolver.BackgroundImage = global::TOP_Manage.Properties.Resources.proximo;
            this.btnVolver.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnVolver.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolver.FlatAppearance.BorderSize = 0;
            this.btnVolver.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnVolver.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnVolver.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolver.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.btnVolver.ForeColor = System.Drawing.Color.Red;
            this.btnVolver.Location = new System.Drawing.Point(50, 1131);
            this.btnVolver.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(98, 110);
            this.btnVolver.TabIndex = 30;
            this.btnVolver.UseCompatibleTextRendering = true;
            this.btnVolver.UseVisualStyleBackColor = false;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // lblNomCamarero
            // 
            this.lblNomCamarero.AutoSize = true;
            this.lblNomCamarero.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.lblNomCamarero.Location = new System.Drawing.Point(1924, 31);
            this.lblNomCamarero.Name = "lblNomCamarero";
            this.lblNomCamarero.Size = new System.Drawing.Size(126, 52);
            this.lblNomCamarero.TabIndex = 44;
            this.lblNomCamarero.Text = "label1";
            this.lblNomCamarero.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nudCant
            // 
            this.nudCant.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.nudCant.Location = new System.Drawing.Point(1517, 1169);
            this.nudCant.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudCant.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCant.Name = "nudCant";
            this.nudCant.Size = new System.Drawing.Size(120, 72);
            this.nudCant.TabIndex = 45;
            this.nudCant.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // errorEntrantes
            // 
            this.errorEntrantes.ContainerControl = this;
            // 
            // FrmEntrante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(2140, 1291);
            this.Controls.Add(this.nudCant);
            this.Controls.Add(this.lblNomCamarero);
            this.Controls.Add(this.gbxEntrantes);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnVolver);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmEntrante";
            this.Text = "Form12";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmEntrante_Load);
            this.gbxEntrantes.ResumeLayout(false);
            this.gbxEntrantes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorEntrantes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxEntrantes;
        private System.Windows.Forms.RadioButton rbtnChickenSalad;
        private System.Windows.Forms.RadioButton rbtnCamembits;
        private System.Windows.Forms.RadioButton rbtn6GarlicBread;
        private System.Windows.Forms.RadioButton rbtnPotatoBacChees;
        private System.Windows.Forms.RadioButton rbtnChickenWings;
        private System.Windows.Forms.RadioButton rbtnCesarSalad;
        private System.Windows.Forms.RadioButton rbtnChickenStrips;
        private System.Windows.Forms.RadioButton rbtn4GarlicBread;
        private System.Windows.Forms.RadioButton rbtnGroveSalad;
        private System.Windows.Forms.RadioButton rbtnNuggets;
        private System.Windows.Forms.RadioButton rbtn4GarlicCheeseBread;
        private System.Windows.Forms.RadioButton rbtnPotatoes;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.RadioButton rbtnChickenWingsCombo;
        private System.Windows.Forms.RadioButton radio6GarlicCheeseBread;
        private System.Windows.Forms.RadioButton rbtnChickenCombo;
        private System.Windows.Forms.Label lblNomCamarero;
        private System.Windows.Forms.NumericUpDown nudCant;
        private System.Windows.Forms.ErrorProvider errorEntrantes;
    }
}