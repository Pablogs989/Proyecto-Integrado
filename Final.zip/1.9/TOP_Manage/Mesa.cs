﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace TOP_Manage
{
    static class Mesa
    {
        public static bool ExisteMesa(MySqlConnection conexion, int nMesa)
        {
            string consulta = string.Format("SELECT * FROM mesas");
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            bool existe = false;
            try
            {
                MySqlDataReader reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (nMesa == reader.GetInt32(0))
                        {
                            existe = true;
                        }
                    }
                }
                reader.Close();
            }
            catch (MySqlException)
            {
                throw;
            }
            return existe;
        }
    }
}
