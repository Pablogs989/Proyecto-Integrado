﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmResumenPedido : Form
    {
        string nCamarero;
        Pedido pedido = Utilidades.Pedido;
        
        public FrmResumenPedido(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Utilidades.Pedido = null;
            FrmVerPedido verPedido = new FrmVerPedido(lblNomCamarero.Text);
            verPedido.ShowDialog();
            this.Hide();
        }

        private void LlenarDtg(DataGridView dtg, List<LineaPedido> lineas)
        {
            dtg.Rows.Clear();
            int i = 1;
            foreach (LineaPedido linea in lineas)
            {
                dtg.Rows.Add(i, linea.Producto.Detalle, linea.Cant);
                i++;
            }
        }

        private void FrmResumenPedido_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
            lblResumen.Text = string.Format("Nº {0} FROM {1}", pedido.NumPedido, pedido.NomCamarero);
            lblPrecio.Text = pedido.GetPrecio().ToString("F");
            lblDatos.Text = pedido.GetDestino();
            foreach (DataGridViewColumn columna in dtgLineas.Columns)
            {
                columna.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            dtgLineas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgLineas.MultiSelect = false;
            dtgLineas.Font = new Font("YuGothicLight", 30);
            ConexionBD conex = new ConexionBD();
            try
            {
                conex.AbrirConexion();
                LlenarDtg(dtgLineas, LineaPedido.GetLineas(conex.Conexion, pedido.NumPedido));
                conex.CerrarConexion();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (dtgLineas.Rows.Count > 0)
            {
                dtgLineas.Rows[0].Selected = true;
            }
        }
    }
}
