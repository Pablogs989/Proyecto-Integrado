﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmBebida : Form
    {
        string nCamarero;
        public FrmBebida(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmProductos productos = new FrmProductos(lblNomCamarero.Text);
            productos.ShowDialog();
            this.Hide();
        }

        private void FrmBebida_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            errorBebidas.Clear();
            bool check = false;
            string detalle = "";
            foreach (RadioButton rbtn in gbxBebidas.Controls)
            {
                if (rbtn.Checked)
                {
                    check = true;
                    detalle = rbtn.Text;
                }
            }
            if (!check)
            {
                errorBebidas.SetError(gbxBebidas, "Please choose a drink");
            }
            else
            {
                Tipo tipo = new Tipo(2, "Bebida");
                ConexionBD conex = new ConexionBD();
                Producto prod = null;
                try
                {
                    conex.AbrirConexion();
                    prod = new Producto(detalle, tipo, Producto.GetPrecio(detalle, conex.Conexion));
                    conex.CerrarConexion();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                LineaPedido linea = new LineaPedido((int)nudCant.Value, prod);
                Utilidades.Pedido.AgregarLinea(linea);
                btnReturn.PerformClick();
            }
        }
    }
}
