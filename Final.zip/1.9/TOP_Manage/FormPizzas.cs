﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmPizza : Form
    {
        string nCamarero;
        public FrmPizza(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmProductos productos = new FrmProductos(lblNomCamarero.Text);
            productos.ShowDialog();
            this.Hide();
        }

        private void FrmPizza_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
            cmbMasas.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTamanyo.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMasas.SelectedIndex = 0;
            cmbTamanyo.SelectedIndex = 0;
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            errorPizzas.Clear();
            bool check = false;
            string sabor = "";
            foreach (RadioButton rbtn in gbxSabores.Controls)
            {
                if (rbtn.Checked)
                {
                    check = true;
                    sabor = rbtn.Text;
                }
            }
            if (!check)
            {
                errorPizzas.SetError(gbxSabores, "Please choose at least one flavor");
            }
            else
            {
                string detalle = string.Format("{0} {1} {2}", sabor, cmbTamanyo.Text, cmbMasas.Text);
                Tipo tipo = new Tipo(1, "Pizza");
                ConexionBD conex = new ConexionBD();
                Producto prod = null;
                try
                {
                    conex.AbrirConexion();
                    prod = new Producto(detalle, tipo, Producto.GetPrecio(detalle, conex.Conexion));
                    conex.CerrarConexion();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                LineaPedido linea = new LineaPedido((int)nudCant.Value, prod);
                Utilidades.Pedido.AgregarLinea(linea);
                btnReturn.PerformClick();
            }
        }
    }
}
