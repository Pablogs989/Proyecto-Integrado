﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmAcabarPedido : Form
    {
        string nCamarero;

        public FrmAcabarPedido(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void LlenarDtg(DataGridView dtg, List<LineaPedido> lineas)
        {
            int cont = 1;
            foreach (LineaPedido linea in lineas)
            {
                dtg.Rows.Add(cont, linea.Producto.Detalle, linea.Cant);
                cont++;
            }
        }

        private void FrmAcabarPedido_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
            lblNomCamarero.Text = nCamarero;
            foreach (DataGridViewColumn columna in dtgResumen.Columns)
            {
                columna.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            dtgResumen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgResumen.MultiSelect = false;
            dtgResumen.Font = new Font("YuGothicLight", 30);
            LlenarDtg(dtgResumen, Utilidades.Pedido.LineasPedido);
            lblPrecio.Text = Utilidades.Pedido.GetPrecio().ToString("F");
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            FrmProductos frmProd = new FrmProductos(lblNomCamarero.Text);
            frmProd.ShowDialog();
            this.Hide();
        }

        private void btnCoupon_Click(object sender, EventArgs e)
        {
            if (txtCoupon.Text != "")
            {
                ConexionBD conex = new ConexionBD();
                try
                {
                    conex.AbrirConexion();
                    if (CodigoDescuento.ComprobarCodigoDescuento(txtCoupon.Text, conex.Conexion))
                    {
                        Utilidades.Pedido.CodDesc = CodigoDescuento.GetCodigoDescuento(txtCoupon.Text, conex.Conexion);
                        lblPrecio.Text = Utilidades.Pedido.GetPrecio().ToString("F");
                        MessageBox.Show("Coupon " + Utilidades.Pedido.CodDesc.Id + " succesfully applied", "Coupon", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Coupon " + txtCoupon.Text + " doesn't exist", "Coupon", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtCoupon.Clear();
                    }
                    conex.CerrarConexion();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            ConexionBD conex = new ConexionBD();
            try
            {
                conex.AbrirConexion();
                Pedido.AgregarPedido(conex.Conexion, Utilidades.Pedido);
                MessageBox.Show("Order Nº" + Pedido.GetUltNumPed(conex.Conexion) + " succesfully done", "DONE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conex.CerrarConexion();
                FrmPrincipal frmPri = new FrmPrincipal(lblNomCamarero.Text);
                frmPri.ShowDialog();
                this.Hide();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
