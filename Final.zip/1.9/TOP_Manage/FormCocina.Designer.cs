﻿
namespace TOP_Manage
{
    partial class FrmCocina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dtgLineas = new System.Windows.Forms.DataGridView();
            this.crono = new System.Windows.Forms.Timer(this.components);
            this.btnReturn = new System.Windows.Forms.Button();
            this.nPed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idLinea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Detalle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tiempo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgLineas)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgLineas
            // 
            this.dtgLineas.AllowUserToAddRows = false;
            this.dtgLineas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dtgLineas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgLineas.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.dtgLineas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgLineas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgLineas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nPed,
            this.idLinea,
            this.Tipo,
            this.Detalle,
            this.Cant,
            this.tiempo});
            this.dtgLineas.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(144)))), ((int)(((byte)(169)))));
            this.dtgLineas.Location = new System.Drawing.Point(12, 12);
            this.dtgLineas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgLineas.Name = "dtgLineas";
            this.dtgLineas.ReadOnly = true;
            this.dtgLineas.RowHeadersWidth = 51;
            this.dtgLineas.RowTemplate.Height = 24;
            this.dtgLineas.Size = new System.Drawing.Size(1878, 922);
            this.dtgLineas.TabIndex = 1;
            this.dtgLineas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtgLineas_KeyPress);
            // 
            // crono
            // 
            this.crono.Enabled = true;
            this.crono.Interval = 15000;
            this.crono.Tick += new System.EventHandler(this.crono_Tick);
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.White;
            this.btnReturn.BackgroundImage = global::TOP_Manage.Properties.Resources.proximo;
            this.btnReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturn.FlatAppearance.BorderSize = 0;
            this.btnReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturn.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.btnReturn.ForeColor = System.Drawing.Color.Red;
            this.btnReturn.Location = new System.Drawing.Point(12, 940);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(87, 88);
            this.btnReturn.TabIndex = 2;
            this.btnReturn.TabStop = false;
            this.btnReturn.UseCompatibleTextRendering = true;
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // nPed
            // 
            this.nPed.HeaderText = "Order Nº";
            this.nPed.MinimumWidth = 9;
            this.nPed.Name = "nPed";
            this.nPed.ReadOnly = true;
            this.nPed.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.nPed.Width = 93;
            // 
            // idLinea
            // 
            this.idLinea.HeaderText = "Line Nº";
            this.idLinea.MinimumWidth = 9;
            this.idLinea.Name = "idLinea";
            this.idLinea.ReadOnly = true;
            this.idLinea.Width = 83;
            // 
            // Tipo
            // 
            this.Tipo.HeaderText = "Type";
            this.Tipo.MinimumWidth = 9;
            this.Tipo.Name = "Tipo";
            this.Tipo.ReadOnly = true;
            this.Tipo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Tipo.Width = 69;
            // 
            // Detalle
            // 
            this.Detalle.HeaderText = "Detail";
            this.Detalle.MinimumWidth = 9;
            this.Detalle.Name = "Detalle";
            this.Detalle.ReadOnly = true;
            this.Detalle.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Detalle.Width = 73;
            // 
            // Cant
            // 
            this.Cant.HeaderText = "Amount";
            this.Cant.MinimumWidth = 9;
            this.Cant.Name = "Cant";
            this.Cant.ReadOnly = true;
            this.Cant.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Cant.Width = 85;
            // 
            // tiempo
            // 
            this.tiempo.HeaderText = "Time";
            this.tiempo.MinimumWidth = 6;
            this.tiempo.Name = "tiempo";
            this.tiempo.ReadOnly = true;
            this.tiempo.Width = 68;
            // 
            // FrmCocina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1726, 882);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.dtgLineas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FrmCocina";
            this.Text = "Form15";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmCocina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgLineas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgLineas;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Timer crono;
        private System.Windows.Forms.DataGridViewTextBoxColumn nPed;
        private System.Windows.Forms.DataGridViewTextBoxColumn idLinea;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Detalle;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cant;
        private System.Windows.Forms.DataGridViewTextBoxColumn tiempo;
    }
}