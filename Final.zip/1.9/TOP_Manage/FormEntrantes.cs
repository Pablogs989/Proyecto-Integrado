﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmEntrante : Form
    {
        string nCamarero;
        public FrmEntrante(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            FrmProductos productos = new FrmProductos(lblNomCamarero.Text);
            productos.ShowDialog();
            this.Hide();
        }

        private void FrmEntrante_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            errorEntrantes.Clear();
            bool check = false;
            string detalle = "";
            foreach (RadioButton rbtn in gbxEntrantes.Controls)
            {
                if (rbtn.Checked)
                {
                    check = true;
                    detalle = rbtn.Text;
                }
            }
            if (!check)
            {
                errorEntrantes.SetError(gbxEntrantes, "Please choose a starter");
            }
            else
            {
                Tipo tipo = new Tipo(4, "Entrante");
                ConexionBD conex = new ConexionBD();
                Producto prod = null;
                try
                {
                    conex.AbrirConexion();
                    prod = new Producto(detalle, tipo, Producto.GetPrecio(detalle, conex.Conexion));
                    conex.CerrarConexion();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                LineaPedido linea = new LineaPedido((int)nudCant.Value, prod);
                Utilidades.Pedido.AgregarLinea(linea);
                btnVolver.PerformClick();
            }
        }
    }
}
