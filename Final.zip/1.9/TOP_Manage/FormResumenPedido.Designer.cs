﻿namespace TOP_Manage
{
    partial class FrmResumenPedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgLineas = new System.Windows.Forms.DataGridView();
            this.lblTituloResumen = new System.Windows.Forms.Label();
            this.lblResumen = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblTituloPrecio = new System.Windows.Forms.Label();
            this.lblDatos = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblNomCamarero = new System.Windows.Forms.Label();
            this.nLinea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.producto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgLineas)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgLineas
            // 
            this.dtgLineas.AllowUserToAddRows = false;
            this.dtgLineas.AllowUserToDeleteRows = false;
            this.dtgLineas.AllowUserToResizeColumns = false;
            this.dtgLineas.AllowUserToResizeRows = false;
            this.dtgLineas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgLineas.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.dtgLineas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgLineas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgLineas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nLinea,
            this.producto,
            this.cant});
            this.dtgLineas.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(144)))), ((int)(((byte)(169)))));
            this.dtgLineas.Location = new System.Drawing.Point(11, 183);
            this.dtgLineas.Name = "dtgLineas";
            this.dtgLineas.RowHeadersWidth = 51;
            this.dtgLineas.RowTemplate.Height = 24;
            this.dtgLineas.Size = new System.Drawing.Size(1878, 839);
            this.dtgLineas.TabIndex = 1;
            // 
            // lblTituloResumen
            // 
            this.lblTituloResumen.AutoSize = true;
            this.lblTituloResumen.Font = new System.Drawing.Font("Yu Gothic Light", 22.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloResumen.Location = new System.Drawing.Point(424, 32);
            this.lblTituloResumen.Name = "lblTituloResumen";
            this.lblTituloResumen.Size = new System.Drawing.Size(352, 49);
            this.lblTituloResumen.TabIndex = 6;
            this.lblTituloResumen.Text = "ORDER SUMMARY:";
            // 
            // lblResumen
            // 
            this.lblResumen.AutoSize = true;
            this.lblResumen.Font = new System.Drawing.Font("Yu Gothic Medium", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResumen.Location = new System.Drawing.Point(787, 32);
            this.lblResumen.Name = "lblResumen";
            this.lblResumen.Size = new System.Drawing.Size(311, 49);
            this.lblResumen.TabIndex = 7;
            this.lblResumen.Text = "-----------------";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Font = new System.Drawing.Font("Yu Gothic Medium", 17.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lblPrecio.Location = new System.Drawing.Point(470, 124);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(238, 38);
            this.lblPrecio.TabIndex = 9;
            this.lblPrecio.Text = "-----------------";
            // 
            // lblTituloPrecio
            // 
            this.lblTituloPrecio.AutoSize = true;
            this.lblTituloPrecio.Font = new System.Drawing.Font("Yu Gothic Light", 17.2F, System.Drawing.FontStyle.Italic);
            this.lblTituloPrecio.Location = new System.Drawing.Point(341, 124);
            this.lblTituloPrecio.Name = "lblTituloPrecio";
            this.lblTituloPrecio.Size = new System.Drawing.Size(103, 38);
            this.lblTituloPrecio.TabIndex = 8;
            this.lblTituloPrecio.Text = "PRICE:";
            // 
            // lblDatos
            // 
            this.lblDatos.AutoSize = true;
            this.lblDatos.Font = new System.Drawing.Font("Yu Gothic Medium", 17.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lblDatos.Location = new System.Drawing.Point(1048, 124);
            this.lblDatos.Name = "lblDatos";
            this.lblDatos.Size = new System.Drawing.Size(238, 38);
            this.lblDatos.TabIndex = 10;
            this.lblDatos.Text = "-----------------";
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.White;
            this.btnReturn.BackgroundImage = global::TOP_Manage.Properties.Resources.proximo;
            this.btnReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturn.FlatAppearance.BorderSize = 0;
            this.btnReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturn.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.btnReturn.ForeColor = System.Drawing.Color.Red;
            this.btnReturn.Location = new System.Drawing.Point(27, 32);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(87, 88);
            this.btnReturn.TabIndex = 21;
            this.btnReturn.UseCompatibleTextRendering = true;
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // lblNomCamarero
            // 
            this.lblNomCamarero.AutoSize = true;
            this.lblNomCamarero.Font = new System.Drawing.Font("Yu Gothic Light", 25F);
            this.lblNomCamarero.Location = new System.Drawing.Point(1758, 26);
            this.lblNomCamarero.Name = "lblNomCamarero";
            this.lblNomCamarero.Size = new System.Drawing.Size(132, 55);
            this.lblNomCamarero.TabIndex = 39;
            this.lblNomCamarero.Text = "label1";
            this.lblNomCamarero.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nLinea
            // 
            this.nLinea.HeaderText = "Line Nº";
            this.nLinea.MinimumWidth = 8;
            this.nLinea.Name = "nLinea";
            this.nLinea.ReadOnly = true;
            this.nLinea.Width = 200;
            // 
            // producto
            // 
            this.producto.HeaderText = "Producto";
            this.producto.MinimumWidth = 8;
            this.producto.Name = "producto";
            this.producto.ReadOnly = true;
            this.producto.Width = 955;
            // 
            // cant
            // 
            this.cant.HeaderText = "Amount";
            this.cant.MinimumWidth = 6;
            this.cant.Name = "cant";
            this.cant.ReadOnly = true;
            this.cant.Width = 125;
            // 
            // FrmResumenPedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1726, 882);
            this.Controls.Add(this.lblNomCamarero);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.lblDatos);
            this.Controls.Add(this.lblPrecio);
            this.Controls.Add(this.lblTituloPrecio);
            this.Controls.Add(this.lblResumen);
            this.Controls.Add(this.lblTituloResumen);
            this.Controls.Add(this.dtgLineas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmResumenPedido";
            this.Text = "Form4";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmResumenPedido_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgLineas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgLineas;
        private System.Windows.Forms.Label lblTituloResumen;
        private System.Windows.Forms.Label lblResumen;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblTituloPrecio;
        private System.Windows.Forms.Label lblDatos;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label lblNomCamarero;
        private System.Windows.Forms.DataGridViewTextBoxColumn nLinea;
        private System.Windows.Forms.DataGridViewTextBoxColumn producto;
        private System.Windows.Forms.DataGridViewTextBoxColumn cant;
    }
}