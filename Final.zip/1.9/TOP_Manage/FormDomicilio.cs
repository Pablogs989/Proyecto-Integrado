﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmDomicilio : Form
    {
        string nCamarero;
        public FrmDomicilio(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmPrincipal principal = new FrmPrincipal(lblNomCamarero.Text);
            principal.ShowDialog();
            this.Hide();
        }

        private void FrmDomicilio_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
            txtTelefono.Focus();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (CamposOk())
            {
                Utilidades.Pedido = new Pedido(lblNomCamarero.Text);
                Utilidades.Pedido.Cliente = GetCliente();
                FrmProductos pedido = new FrmProductos(lblNomCamarero.Text);
                pedido.ShowDialog();
                this.Dispose();
            }
        }

        private Cliente GetCliente()
        {
            Cliente cli = new Cliente(txtTelefono.Text, txtNombre.Text, txtCalle.Text, txtNumero.Text);
            if (txtBloque.Text != "")
            {
                cli.Bloque = txtBloque.Text;
            }
            if (txtEscalera.Text != "")
            {
                cli.Escalera = txtEscalera.Text;
            }
            if (txtPiso.Text != "")
            {
                cli.Piso = txtPiso.Text;
            }
            if (txtPuerta.Text != "")
            {
                cli.Puerta = txtPuerta.Text;
            }
            return cli;
        }

        private void LlenarCamposCli(Cliente cli)
        {
            txtNombre.Text = cli.Nombre;
            txtCalle.Text = cli.Calle;
            txtNumero.Text = cli.Portal;
            txtBloque.Text = cli.Bloque;
            txtEscalera.Text = cli.Escalera;
            txtPiso.Text = cli.Piso;
            txtPuerta.Text = cli.Puerta;
        }

        private bool CamposOk()
        {
            errorCampos.Clear();
            bool ok = true;
            int result;
            if (txtTelefono.Text.Length != 9 || !int.TryParse(txtTelefono.Text, out result))
            {
                ok = false;
                errorCampos.SetError(txtTelefono, "Please type a valid number");
            }
            if (txtNombre.Text == "")
            {
                ok = false;
                errorCampos.SetError(txtNombre, "'Name' field can't be empty");
            }
            if (txtCalle.Text == "")
            {
                ok = false;
                errorCampos.SetError(txtCalle, "'Street' field can't be empty");
            }
            if (!int.TryParse(txtNumero.Text, out result) || txtNumero.Text.Length > 4)
            {
                ok = false;
                errorCampos.SetError(txtNumero, "Please type a number with less than 5 digits");
            }
            if (txtBloque.Text != "" && txtBloque.Text.Length != 1)
            {
                ok = false;
                errorCampos.SetError(txtBloque, "'Block' must be one character");
            }
            if (txtEscalera.Text != "" && txtEscalera.Text.Length != 1)
            {
                ok = false;
                errorCampos.SetError(txtEscalera, "'Stair' must be one character");
            }
            if (txtPiso.Text != "" && (txtPiso.Text.Length > 3 || !int.TryParse(txtPiso.Text, out result)))
            {
                ok = false;
                errorCampos.SetError(txtPiso, "'Floor' must be a number with less than 4 digits");
            }
            if (txtPuerta.Text != "" && (txtPuerta.Text.Length > 4 || !int.TryParse(txtPuerta.Text, out result)))
            {
                ok = false;
                errorCampos.SetError(txtPuerta, "'Door' must be a number with less than 5 digits");
            }
            return ok;
        }

        private void txtTelefono_Leave(object sender, EventArgs e)
        {
            try
            {
                ConexionBD conex = new ConexionBD();
                conex.AbrirConexion();
                if (Cliente.GetCliente(txtTelefono.Text, conex.Conexion) != null)
                {
                    Cliente cli = Cliente.GetCliente(txtTelefono.Text, conex.Conexion);
                    LlenarCamposCli(cli);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
