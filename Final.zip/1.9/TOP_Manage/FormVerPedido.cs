﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmVerPedido : Form
    {
        string nCamarero;
        public FrmVerPedido(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmPrincipal principal = new FrmPrincipal(lblNomCamarero.Text);
            principal.ShowDialog();
            this.Hide();
        }

        private void FrmVerPedido_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
            foreach (DataGridViewColumn columna in dtgPedidos.Columns)
            {
                columna.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            dtgPedidos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgPedidos.MultiSelect = false;
            dtgPedidos.Font = new Font("YuGothicLight", 30);
            ConexionBD conex = new ConexionBD();
            try
            {
                conex.AbrirConexion();
                LlenarDtg(dtgPedidos, Pedido.GetPedidosHoy(conex.Conexion));
                conex.CerrarConexion();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (dtgPedidos.Rows.Count > 0)
            {
                dtgPedidos.Rows[0].Selected = true;
            }
        }

        private void LlenarDtg(DataGridView dtg, List<Pedido> pedidos)
        {
            dtg.Rows.Clear();
            foreach (Pedido pedido in pedidos)
            {
                dtg.Rows.Add(pedido.NumPedido, pedido.GetDestino(), pedido.NomCamarero);
            }
        }

        private void VerPedido(MySqlConnection conex, int nPed)
        {
            conex.Open();
            Utilidades.Pedido = Pedido.GetPedido(conex, nPed);
            FrmResumenPedido frm = new FrmResumenPedido(nCamarero);
            frm.ShowDialog();
            this.Hide();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            int result;
            if (int.TryParse(txtPedido.Text, out result))
            {
                try
                {
                    ConexionBD conex = new ConexionBD();
                    if (Pedido.GetPedido(conex.Conexion, result) != null)
                    {
                        VerPedido(conex.Conexion, result);
                    }
                    else
                    {
                        MessageBox.Show("THE ORDER DOESN'T EXIST", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("PLEASE TYPE A NUMBER", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dtgPedidos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ConexionBD conex = new ConexionBD();
            VerPedido(conex.Conexion, (int)dtgPedidos.SelectedRows[0].Cells[0].Value);
        }
    }
}
