﻿namespace TOP_Manage
{
    partial class FrmPostre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.rbtnBrownie = new System.Windows.Forms.RadioButton();
            this.gbxPostres = new System.Windows.Forms.GroupBox();
            this.rbtnCookies = new System.Windows.Forms.RadioButton();
            this.rbtnChococheese = new System.Windows.Forms.RadioButton();
            this.rbtnVulcano = new System.Windows.Forms.RadioButton();
            this.rbtnHeladoPeanut = new System.Windows.Forms.RadioButton();
            this.rbtnHeladoBrownie = new System.Windows.Forms.RadioButton();
            this.rbtnHeladoCookies = new System.Windows.Forms.RadioButton();
            this.rbtnHeladoTartaFresa = new System.Windows.Forms.RadioButton();
            this.rbtnTartaChocolate = new System.Windows.Forms.RadioButton();
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblNomCamarero = new System.Windows.Forms.Label();
            this.nudCant = new System.Windows.Forms.NumericUpDown();
            this.errorPostres = new System.Windows.Forms.ErrorProvider(this.components);
            this.gbxPostres.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPostres)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(1)))), ((int)(((byte)(1)))));
            this.btnAgregar.FlatAppearance.BorderSize = 0;
            this.btnAgregar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(242)))), ((int)(((byte)(245)))));
            this.btnAgregar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(218)))), ((int)(((byte)(218)))));
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Yu Gothic Light", 17F);
            this.btnAgregar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(194)))), ((int)(((byte)(209)))));
            this.btnAgregar.Location = new System.Drawing.Point(1706, 1172);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(377, 75);
            this.btnAgregar.TabIndex = 24;
            this.btnAgregar.Text = "RESUME";
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // rbtnBrownie
            // 
            this.rbtnBrownie.AutoSize = true;
            this.rbtnBrownie.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnBrownie.Location = new System.Drawing.Point(84, 130);
            this.rbtnBrownie.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnBrownie.Name = "rbtnBrownie";
            this.rbtnBrownie.Size = new System.Drawing.Size(189, 56);
            this.rbtnBrownie.TabIndex = 25;
            this.rbtnBrownie.TabStop = true;
            this.rbtnBrownie.Text = "Brownie";
            this.rbtnBrownie.UseVisualStyleBackColor = true;
            // 
            // gbxPostres
            // 
            this.gbxPostres.Controls.Add(this.rbtnCookies);
            this.gbxPostres.Controls.Add(this.rbtnChococheese);
            this.gbxPostres.Controls.Add(this.rbtnVulcano);
            this.gbxPostres.Controls.Add(this.rbtnHeladoPeanut);
            this.gbxPostres.Controls.Add(this.rbtnHeladoBrownie);
            this.gbxPostres.Controls.Add(this.rbtnHeladoCookies);
            this.gbxPostres.Controls.Add(this.rbtnHeladoTartaFresa);
            this.gbxPostres.Controls.Add(this.rbtnTartaChocolate);
            this.gbxPostres.Controls.Add(this.rbtnBrownie);
            this.gbxPostres.Location = new System.Drawing.Point(289, 282);
            this.gbxPostres.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxPostres.Name = "gbxPostres";
            this.gbxPostres.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxPostres.Size = new System.Drawing.Size(1558, 597);
            this.gbxPostres.TabIndex = 26;
            this.gbxPostres.TabStop = false;
            // 
            // rbtnCookies
            // 
            this.rbtnCookies.AutoSize = true;
            this.rbtnCookies.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnCookies.Location = new System.Drawing.Point(84, 256);
            this.rbtnCookies.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnCookies.Name = "rbtnCookies";
            this.rbtnCookies.Size = new System.Drawing.Size(184, 56);
            this.rbtnCookies.TabIndex = 33;
            this.rbtnCookies.TabStop = true;
            this.rbtnCookies.Text = "Cookies";
            this.rbtnCookies.UseVisualStyleBackColor = true;
            // 
            // rbtnChococheese
            // 
            this.rbtnChococheese.AutoSize = true;
            this.rbtnChococheese.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnChococheese.Location = new System.Drawing.Point(84, 384);
            this.rbtnChococheese.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnChococheese.Name = "rbtnChococheese";
            this.rbtnChococheese.Size = new System.Drawing.Size(280, 56);
            this.rbtnChococheese.TabIndex = 32;
            this.rbtnChococheese.TabStop = true;
            this.rbtnChococheese.Text = "Chococheese";
            this.rbtnChococheese.UseVisualStyleBackColor = true;
            // 
            // rbtnVulcano
            // 
            this.rbtnVulcano.AutoSize = true;
            this.rbtnVulcano.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnVulcano.Location = new System.Drawing.Point(576, 130);
            this.rbtnVulcano.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnVulcano.Name = "rbtnVulcano";
            this.rbtnVulcano.Size = new System.Drawing.Size(184, 56);
            this.rbtnVulcano.TabIndex = 31;
            this.rbtnVulcano.TabStop = true;
            this.rbtnVulcano.Text = "Vulcano";
            this.rbtnVulcano.UseVisualStyleBackColor = true;
            // 
            // rbtnHeladoPeanut
            // 
            this.rbtnHeladoPeanut.AutoSize = true;
            this.rbtnHeladoPeanut.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHeladoPeanut.Location = new System.Drawing.Point(576, 256);
            this.rbtnHeladoPeanut.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnHeladoPeanut.Name = "rbtnHeladoPeanut";
            this.rbtnHeladoPeanut.Size = new System.Drawing.Size(334, 56);
            this.rbtnHeladoPeanut.TabIndex = 30;
            this.rbtnHeladoPeanut.TabStop = true;
            this.rbtnHeladoPeanut.Text = "PeanutIceCream";
            this.rbtnHeladoPeanut.UseVisualStyleBackColor = true;
            // 
            // rbtnHeladoBrownie
            // 
            this.rbtnHeladoBrownie.AutoSize = true;
            this.rbtnHeladoBrownie.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHeladoBrownie.Location = new System.Drawing.Point(576, 384);
            this.rbtnHeladoBrownie.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnHeladoBrownie.Name = "rbtnHeladoBrownie";
            this.rbtnHeladoBrownie.Size = new System.Drawing.Size(353, 56);
            this.rbtnHeladoBrownie.TabIndex = 29;
            this.rbtnHeladoBrownie.TabStop = true;
            this.rbtnHeladoBrownie.Text = "BrownieIceCream";
            this.rbtnHeladoBrownie.UseVisualStyleBackColor = true;
            // 
            // rbtnHeladoCookies
            // 
            this.rbtnHeladoCookies.AutoSize = true;
            this.rbtnHeladoCookies.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHeladoCookies.Location = new System.Drawing.Point(1091, 130);
            this.rbtnHeladoCookies.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnHeladoCookies.Name = "rbtnHeladoCookies";
            this.rbtnHeladoCookies.Size = new System.Drawing.Size(348, 56);
            this.rbtnHeladoCookies.TabIndex = 28;
            this.rbtnHeladoCookies.TabStop = true;
            this.rbtnHeladoCookies.Text = "CookiesIceCream";
            this.rbtnHeladoCookies.UseVisualStyleBackColor = true;
            // 
            // rbtnHeladoTartaFresa
            // 
            this.rbtnHeladoTartaFresa.AutoSize = true;
            this.rbtnHeladoTartaFresa.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnHeladoTartaFresa.Location = new System.Drawing.Point(1091, 256);
            this.rbtnHeladoTartaFresa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnHeladoTartaFresa.Name = "rbtnHeladoTartaFresa";
            this.rbtnHeladoTartaFresa.Size = new System.Drawing.Size(398, 56);
            this.rbtnHeladoTartaFresa.TabIndex = 27;
            this.rbtnHeladoTartaFresa.TabStop = true;
            this.rbtnHeladoTartaFresa.Text = "StrawCakeIceCream";
            this.rbtnHeladoTartaFresa.UseVisualStyleBackColor = true;
            // 
            // rbtnTartaChocolate
            // 
            this.rbtnTartaChocolate.AutoSize = true;
            this.rbtnTartaChocolate.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.rbtnTartaChocolate.Location = new System.Drawing.Point(1091, 384);
            this.rbtnTartaChocolate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtnTartaChocolate.Name = "rbtnTartaChocolate";
            this.rbtnTartaChocolate.Size = new System.Drawing.Size(307, 56);
            this.rbtnTartaChocolate.TabIndex = 26;
            this.rbtnTartaChocolate.TabStop = true;
            this.rbtnTartaChocolate.Text = "ChocolateCake";
            this.rbtnTartaChocolate.UseVisualStyleBackColor = true;
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.White;
            this.btnReturn.BackgroundImage = global::TOP_Manage.Properties.Resources.proximo;
            this.btnReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturn.FlatAppearance.BorderSize = 0;
            this.btnReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturn.Font = new System.Drawing.Font("Yu Gothic Light", 22F);
            this.btnReturn.ForeColor = System.Drawing.Color.Red;
            this.btnReturn.Location = new System.Drawing.Point(60, 1138);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(98, 110);
            this.btnReturn.TabIndex = 23;
            this.btnReturn.UseCompatibleTextRendering = true;
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // lblNomCamarero
            // 
            this.lblNomCamarero.AutoSize = true;
            this.lblNomCamarero.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.lblNomCamarero.Location = new System.Drawing.Point(2005, 11);
            this.lblNomCamarero.Name = "lblNomCamarero";
            this.lblNomCamarero.Size = new System.Drawing.Size(126, 52);
            this.lblNomCamarero.TabIndex = 43;
            this.lblNomCamarero.Text = "label1";
            this.lblNomCamarero.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nudCant
            // 
            this.nudCant.Font = new System.Drawing.Font("Yu Gothic Light", 20F);
            this.nudCant.Location = new System.Drawing.Point(1541, 1172);
            this.nudCant.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudCant.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCant.Name = "nudCant";
            this.nudCant.Size = new System.Drawing.Size(120, 72);
            this.nudCant.TabIndex = 46;
            this.nudCant.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // errorPostres
            // 
            this.errorPostres.ContainerControl = this;
            // 
            // FrmPostre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(2140, 1291);
            this.Controls.Add(this.nudCant);
            this.Controls.Add(this.lblNomCamarero);
            this.Controls.Add(this.gbxPostres);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnReturn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmPostre";
            this.Text = "Form10";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmPostre_Load);
            this.gbxPostres.ResumeLayout(false);
            this.gbxPostres.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPostres)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.RadioButton rbtnBrownie;
        private System.Windows.Forms.GroupBox gbxPostres;
        private System.Windows.Forms.RadioButton rbtnCookies;
        private System.Windows.Forms.RadioButton rbtnChococheese;
        private System.Windows.Forms.RadioButton rbtnVulcano;
        private System.Windows.Forms.RadioButton rbtnHeladoPeanut;
        private System.Windows.Forms.RadioButton rbtnHeladoBrownie;
        private System.Windows.Forms.RadioButton rbtnHeladoCookies;
        private System.Windows.Forms.RadioButton rbtnHeladoTartaFresa;
        private System.Windows.Forms.RadioButton rbtnTartaChocolate;
        private System.Windows.Forms.Label lblNomCamarero;
        private System.Windows.Forms.NumericUpDown nudCant;
        private System.Windows.Forms.ErrorProvider errorPostres;
    }
}