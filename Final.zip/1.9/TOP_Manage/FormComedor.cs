﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmComedor : Form
    {
        string nCamarero;
        public FrmComedor(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            int result;
            if (int.TryParse(txtMesa.Text, out result))
            {
                try
                {
                    ConexionBD conex = new ConexionBD();
                    conex.AbrirConexion();
                    if (Mesa.ExisteMesa(conex.Conexion, result))
                    {
                        Utilidades.Pedido = new Pedido(lblNomCamarero.Text);
                        FrmProductos pedido = new FrmProductos(lblNomCamarero.Text);
                        pedido.ShowDialog();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("The table doesn't exist", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    conex.CerrarConexion();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Type a number", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmPrincipal principal = new FrmPrincipal(lblNomCamarero.Text);
            principal.ShowDialog();
            this.Hide();
        }

        private void FrmComedor_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
            txtMesa.Focus();
        }
    }
}