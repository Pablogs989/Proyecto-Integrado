﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace TOP_Manage
{
    static class Utilidades
    {
        private static Pedido pedido;
        public static Pedido Pedido { get { return pedido; } set { pedido = value; } }

        public static bool ValidaUsuario(MySqlConnection conexion, string usuario, string passwd)
        {
            string consulta = string.Format("SELECT nombre FROM empleado WHERE passwd = '{0}';", passwd);
            MySqlCommand comando = new MySqlCommand(consulta, conexion);
            bool valida = false;
            MySqlDataReader reader = null;
            try
            {
                reader = comando.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (reader.GetString(0) == usuario)
                        {
                            valida = true;
                        }
                    }
                }
                reader.Close();
            }
            catch (MySqlException)
            {
                throw;
            }
            finally
            {
                reader.Close();
            }
            return valida;
        }
    }
}