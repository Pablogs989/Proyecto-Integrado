﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TOP_Manage
{
    public partial class FrmCerrarPedido : Form
    {
        string nCamarero;

        public FrmCerrarPedido(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmPrincipal principal = new FrmPrincipal(lblNomCamarero.Text);
            principal.ShowDialog();
            this.Hide();
        }

        private void LlenarDtg(DataGridView dtg, List<Pedido> pedidos)
        {
            dtg.Rows.Clear();
            foreach (Pedido pedido in pedidos)
            {
                dtg.Rows.Add(pedido.NumPedido, pedido.GetDestino(), pedido.NomCamarero);
            }
        }

        private void CerrarCancelar(int nPed)
        {
            ConexionBD conex = new ConexionBD();
            DialogResult result = MessageBox.Show("YES: Sets order as paid\r\nNO: Closes this message\r\nCANCEL: Cancels the order", "'Close order' options", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            bool mod = false;
            if (result == DialogResult.Yes)
            {
                CerrarPedido(conex.Conexion, nPed);
                mod = true;
            }
            else if (result == DialogResult.Cancel)
            {
                CancelarPedido(conex.Conexion, nPed);
                mod = true;
            }
            if (mod)
            {
                try
                {
                    conex.AbrirConexion();
                    LlenarDtg(dtgPedidos, Pedido.GetPedidosNoPagados(conex.Conexion));
                    conex.CerrarConexion();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void CancelarPedido(MySqlConnection conex, int nPed)
        {
            try
            {
                conex.Open();
                Pedido.SetCancelado(conex, nPed);
                conex.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CerrarPedido(MySqlConnection conex, int nPed)
        {
            try
            {
                conex.Open();
                Pedido.SetPagado(conex, nPed);
                conex.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmCerrarPedido_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
            foreach (DataGridViewColumn columna in dtgPedidos.Columns)
            {
                columna.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            dtgPedidos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgPedidos.MultiSelect = false;
            dtgPedidos.Font = new Font("YuGothicLight", 30);
            ConexionBD conex = new ConexionBD();
            try
            {
                conex.AbrirConexion();
                LlenarDtg(dtgPedidos, Pedido.GetPedidosNoPagados(conex.Conexion));
                conex.CerrarConexion();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (dtgPedidos.Rows.Count > 0)
            {
                dtgPedidos.Rows[0].Selected = true;
            }
        }

        private void dtgPedidos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Space)
            {
                CerrarCancelar((int)dtgPedidos.SelectedRows[0].Cells[0].Value);
            }
        }

        private void dtgPedidos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            CerrarCancelar((int)dtgPedidos.SelectedRows[0].Cells[0].Value);
        }
    }
}
