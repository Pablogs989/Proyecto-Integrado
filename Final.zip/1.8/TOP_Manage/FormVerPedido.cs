﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOP_Manage
{
    public partial class FrmVerPedido : Form
    {
        string nCamarero;
        public FrmVerPedido(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmPrincipal principal = new FrmPrincipal(lblNomCamarero.Text);
            principal.ShowDialog();
            this.Hide();
        }

        private void FrmVerPedido_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            int result;
            if (int.TryParse(txtPedido.Text, out result))
            {
                ConexionBD conex = new ConexionBD();
                conex.AbrirConexion();
                if (Pedido.GetPedido(conex.Conexion, result) != null)
                {
                    FrmResumenPedido frm;
                }
                else
                {
                    MessageBox.Show("THE ORDER DOESN'T EXIST", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("PLEASE TYPE A NUMBER", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
