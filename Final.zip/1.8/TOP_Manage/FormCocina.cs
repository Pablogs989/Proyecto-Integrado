﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOP_Manage
{
    public partial class FrmCocina : Form
    {
        public FrmCocina()
        {
            InitializeComponent();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmContraseña contrasenya = new FrmContraseña();
            contrasenya.ShowDialog();
            this.Hide();
        }

        private void LlenarDtg(DataGridView dtg, List<LineaPedido> lineas)
        {
            dtg.Rows.Clear();
            foreach (LineaPedido linea in lineas)
            {
                if (linea.Producto.Tipo.Descripcion != "Bebida")
                {
                    dtg.Rows.Add(linea.NPed, linea.Id, linea.Producto.Tipo.Descripcion, linea.Producto.Detalle, linea.Cant);
                }
            }
        }

        private void FrmCocina_Load(object sender, EventArgs e)
        {
            foreach (DataGridViewColumn columna in dtgLineas.Columns)
            {
                columna.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            dtgLineas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgLineas.MultiSelect = false;
            dtgLineas.Font = new Font("YuGothicLight", 30);
            ConexionBD conex = new ConexionBD();
            conex.AbrirConexion();
            LlenarDtg(dtgLineas, LineaPedido.GetLineasNoHechas(conex.Conexion));
            conex.CerrarConexion();
            if (dtgLineas.Rows.Count > 0)
            {
                dtgLineas.Rows[0].Selected = true;
            }
        }

        private bool ExistePedido(DataGridView dtg, int nPed)
        {
            bool existe = false;
            foreach (DataGridViewRow fila in dtg.Rows)
            {
                if (nPed == (int)fila.Cells[0].Value)
                {
                    existe = true;
                }
            }
            return existe;
        }

        private void dtgLineas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Space)
            {
                string messageBox = string.Format("IS {0} {1} DONE?", dtgLineas.SelectedRows[0].Cells[2].Value, dtgLineas.SelectedRows[0].Cells[3].Value);
                DialogResult result = MessageBox.Show(messageBox, "WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    int pedLineaBorrada = (int)dtgLineas.SelectedRows[0].Cells[0].Value;
                    ConexionBD conex = new ConexionBD();
                    conex.AbrirConexion();
                    LineaPedido.SetHecha(conex.Conexion, (int)dtgLineas.SelectedRows[0].Cells[1].Value);
                    LlenarDtg(dtgLineas, LineaPedido.GetLineasNoHechas(conex.Conexion));
                    conex.CerrarConexion();
                    if (!ExistePedido(dtgLineas, pedLineaBorrada))
                    {
                        MessageBox.Show("ORDER Nº " + pedLineaBorrada + " FINISHED", "FINISHED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }
        }

        private void crono_Tick(object sender, EventArgs e)
        {
            ConexionBD conex = new ConexionBD();
            conex.AbrirConexion();
            int index = 0;
            if (dtgLineas.Rows.Count > 0)
            {
                index = dtgLineas.SelectedRows[0].Index;
            }
            LlenarDtg(dtgLineas, LineaPedido.GetLineasNoHechas(conex.Conexion));
            if (dtgLineas.Rows.Count > 0)
            {
                dtgLineas.Rows[index].Selected = true;
            }
            conex.CerrarConexion();
        }
    }
}
