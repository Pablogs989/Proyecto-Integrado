﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TOP_Manage
{
    public partial class FrmCerrarPedido : Form
    {
        string nCamarero;

        public FrmCerrarPedido(string nomCamarero)
        {
            InitializeComponent();
            nCamarero = nomCamarero;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            FrmPrincipal principal = new FrmPrincipal(lblNomCamarero.Text);
            principal.ShowDialog();
            this.Hide();
        }

        private void LlenarDtg(DataGridView dtg, List<Pedido> pedidos)
        {
            dtg.Rows.Clear();
            foreach (Pedido pedido in pedidos)
            {
                dtg.Rows.Add(pedido.NumPedido, pedido.GetDestino(), pedido.NumPedido);
            }
        }

        private void FrmCerrarPedido_Load(object sender, EventArgs e)
        {
            lblNomCamarero.Text = nCamarero;
            foreach (DataGridViewColumn columna in dtgPedidos.Columns)
            {
                columna.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            dtgPedidos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtgPedidos.MultiSelect = false;
            dtgPedidos.Font = new Font("YuGothicLight", 30);
            ConexionBD conex = new ConexionBD();
            conex.AbrirConexion();
            LlenarDtg(dtgPedidos, Pedido.GetPedidosNoPagados(conex.Conexion));
            conex.CerrarConexion();
            if (dtgPedidos.Rows.Count > 0)
            {
                dtgPedidos.Rows[0].Selected = true;
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure that you want to close this App?",
                                                 "Confirm Delete!",
                                                 MessageBoxButtons.YesNoCancel, MessageBoxIcon.Error);
            if (confirmResult == DialogResult.Yes)
            {

            }
        }
    }
}
